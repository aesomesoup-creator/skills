# Checklist vibe-audit

Tout ce qu'on oublie quand on vibe code un site, une app ou un SaaS. Regroupé depuis des vidéos de veille sur le vibe coding, plus quelques pièges fréquents que les vidéos ne couvrent pas.

## Sources

- **[20pts]** Checklist de 20 points de sécurité à vérifier avant de lancer un SaaS (The Saas Daddy) : https://www.instagram.com/reel/DcJPUMvM3D0/
- **[5failles]** 5 failles de sécurité classiques sur une page de connexion générée par IA (The Saas Daddy) : https://www.instagram.com/reel/DcL_P_mMcEs/
- **[légal]** Checklist légale à donner à Claude pour un site vibe codé (0xloucash) : https://www.tiktok.com/@0xloucash/video/7687273339257097504
- **[speckit]** GitHub Spec Kit : cadrer un projet avant de le coder avec l'IA (Simon De Lima) : https://www.instagram.com/reel/Db_V0OQsnIH/
- **[usine]** Usine à mini-SaaS en vibe coding : ça marche, mais ça ne se vend plus (rudy.io) : https://www.tiktok.com/@rudy.io/video/7657493355252731168
- **[apple]** Un skill Claude qui applique les règles du design system Apple (Arms) : https://www.instagram.com/reel/DbwUd4tNxa1/
- **[ponytail]** Ponytail, le plugin qui force l'IA à écrire moins de code (codenameposhan) : https://www.tiktok.com/@codenameposhan/video/7683368256182193439
- **[compl.]** Compléments hors vidéos, tirés de https://github.com/benavlabs/vibe-check et https://github.com/raroque/vibe-security-skill

## Sévérités

- 🔴 **bloquant** : fuite de données, d'argent ou de comptes. Pas de mise en prod tant que c'est ouvert.
- 🟠 **important** : à corriger avant d'ouvrir au public ou d'encaisser.
- 🟡 **hygiène** : améliore la qualité, ne bloque pas.

## Format d'un point

`ID · titre — sévérité`, puis : **Source** · **Si** (condition d'application, liée aux drapeaux du profil) · **Pourquoi** · **Vérifier** · **Corriger**.

---

## 1. CAD — Cadrage du projet

### CAD-1 · Fichier de règles pour l'IA — 🟡
- **Source** : [speckit] · **Si** : toujours
- **Pourquoi** : sans règles écrites, chaque session réinvente la stack et les conventions ; avec plusieurs projets en parallèle, la cohérence s'effondre.
- **Vérifier** : un `CLAUDE.md`, `AGENTS.md`, `.cursorrules` ou `.github/copilot-instructions.md` existe et donne au moins la stack, les commandes (dev, build, test), les conventions et les contraintes (budget infra, hébergeur).
- **Corriger** : un `CLAUDE.md` court avec ces quatre rubriques.

### CAD-2 · Objectif et périmètre écrits — 🟡
- **Source** : [speckit] · **Si** : toujours
- **Pourquoi** : une spec avant le code évite les features à moitié finies et les dérives au fil des prompts.
- **Vérifier** : le README (ou `specs/`, `docs/`) dit ce que fait le projet, pour qui, et ce qui est hors périmètre. Un README de template jamais modifié (create-next-app, Vite, Expo) compte comme ❌.
- **Corriger** : dix lignes dans le README : problème, utilisateur cible, fonctionnalités v1, hors périmètre.

### CAD-3 · Lignes rouges pour les agents — 🟡 (🟠 si des agents tournent en autonomie)
- **Source** : [usine] · **Si** : toujours
- **Pourquoi** : un agent en boucle sans garde-fou peut encaisser, écrire à des clients ou supprimer des données.
- **Vérifier** : les règles (CAD-1) listent ce que l'agent ne fait jamais seul : paiements, emails aux clients, suppression de données, DNS, déploiement sans rollback. Dans `.claude/settings.json` et `.claude/settings.local.json`, repérer les permissions trop larges en `allow` (`Bash(*)`, `rm`, commandes de deploy ou de prod).
- **Corriger** : une section « Lignes rouges » dans le `CLAUDE.md` et des règles `deny` ou `ask` dans les settings.

### CAD-4 · Plan de distribution — 🟡 (question, pas de vérification de code)
- **Source** : [usine] · **Si** : projet destiné à des utilisateurs externes ou payant
- **Pourquoi** : produire ne coûte presque plus rien : 13 SaaS en prod peuvent faire zéro client payant. La distribution est devenue le vrai travail.
- **Vérifier** : chercher dans le README ou la spec : qui sont les 10 premiers utilisateurs, par quel canal ils arrivent, pourquoi ils paieraient. Absent → ❓ « question à te poser », sans bloquer l'audit.
- **Corriger** : l'écrire avant d'ajouter des features. Pour aller plus loin : skills `launch`, `product-marketing`.

---

## 2. SEC — Secrets et clés

Rappel : ne jamais ouvrir les vrais `.env`. Grep en mode fichiers d'abord, puis citer `fichier:ligne` + nom de variable + 4 premiers caractères au maximum.

### SEC-1 · Aucun secret en dur dans le code — 🔴
- **Source** : [20pts] · **Si** : toujours
- **Pourquoi** : une clé écrite dans le code finit sur GitHub, dans le bundle ou dans une capture d'écran.
- **Vérifier** : Grep (`files_with_matches`) dans le code source avec ces motifs :
  - `sk_live_|rk_live_|sk_test_` (Stripe)
  - `sk-ant-|sk-proj-|sk-[A-Za-z0-9]{32,}` (Anthropic, OpenAI)
  - `AKIA[0-9A-Z]{16}` (AWS)
  - `ghp_[A-Za-z0-9]{36}|github_pat_` (GitHub)
  - `xox[abprs]-` (Slack)
  - `-----BEGIN [A-Z ]*PRIVATE KEY-----`
  - `service_role`
  - `eyJhbGciOi[A-Za-z0-9_-]{20,}` (JWT, dont les clés Supabase)
  - `(api[_-]?key|secret|password|passwd|token)\s*[:=]\s*['"][^'"]{12,}['"]` (insensible à la casse)
- **Faux positifs** : valeurs factices dans `.env.example` ou les tests ; clés publiques par nature (clé `anon` Supabase, clé web Firebase `AIza…`, `pk_live_` Stripe). Pour un JWT Supabase, le nom de la variable suffit en général ; en cas de doute, décoder localement le 2e segment et ne rapporter que le champ `role` (`anon` = public, `service_role` = secret).
- **Corriger** : déplacer dans `.env`, lire la variable côté serveur, et faire tourner la clé si elle a été commitée (SEC-2).

### SEC-2 · `.env` ignoré par git et jamais commité — 🔴
- **Source** : [20pts] · **Si** : dépôt git
- **Pourquoi** : un secret poussé sur GitHub est compromis, même après suppression du commit : des robots scannent GitHub en continu.
- **Vérifier** :
  - `git check-ignore -q .env && echo ignoré` (idem `.env.local`, `.env.production`, et les `.env` des sous-dossiers d'un monorepo) ;
  - `git ls-files | grep -E '(^|/)\.env($|\.)' | grep -vE '\.(example|sample|template)$'` → doit être vide ;
  - `git log --all --pretty=format: --name-only -- '*.env' '*.env.*' | sort -u | grep -vE '\.(example|sample|template)$'` → doit être vide (liste des `.env` présents à un moment dans l'historique).
- **Corriger** : `.env*` et `!.env.example` dans le `.gitignore`, `git rm --cached <fichier>`, puis **révoquer et régénérer chaque clé concernée chez le fournisseur** : réécrire l'historique ne suffit pas si le repo a été poussé.

### SEC-3 · Seule la clé publique côté client — 🔴
- **Source** : [20pts] · **Si** : `web` ou `mobile`
- **Pourquoi** : tout ce qui porte un préfixe public est inclus dans le JavaScript envoyé au navigateur ; tout ce qui est dans une app mobile s'extrait.
- **Vérifier** :
  - Variables publiques (dans `.env.example`, le code, `next.config.*`, `app.config.*`) : `NEXT_PUBLIC_`, `VITE_`, `EXPO_PUBLIC_`, `REACT_APP_`, `PUBLIC_`, `NUXT_PUBLIC_`, `GATSBY_`. Aucune ne doit contenir `SECRET`, `SERVICE_ROLE`, `PRIVATE`, `STRIPE_SECRET`, ni une clé d'API d'IA (`OPENAI`, `ANTHROPIC`, `GEMINI`, `MISTRAL`, `REPLICATE`…).
  - SDK privilégiés importés côté client : client Supabase créé avec la service role, SDK `stripe` serveur, `openai` ou `@anthropic-ai/sdk` dans un fichier `'use client'`, un composant, ou le code d'une app Expo / React Native.
  - Si un build existe (`.next/static`, `dist/`, `build/`) : Grep `files_with_matches` des motifs de SEC-1 dedans.
  - Mobile : aucune clé secrète dans `app.json`, `app.config.*`, `eas.json` (bloc `extra`) ou le bundle.
- **Corriger** : passer l'appel par une route serveur ou une edge function qui garde la clé, retirer le préfixe public, faire tourner la clé exposée.

### SEC-4 · Pas de source maps publiques en prod — 🟡
- **Source** : [compl.] · **Si** : `web`
- **Pourquoi** : elles publient ton code source lisible, commentaires compris.
- **Vérifier** : `productionBrowserSourceMaps: true` (Next), `build.sourcemap: true` (Vite) sans envoi privé vers un outil de monitoring ; fichiers `*.map` dans le build déployé.
- **Corriger** : les désactiver, ou les envoyer uniquement à Sentry (ou équivalent) sans les publier.

---

## 3. AUTH — Authentification

Si l'auth est déléguée à un fournisseur (Supabase Auth, Clerk, Auth0, Firebase Auth, Auth.js avec OAuth…), AUTH-1, 3 et 4 sont en grande partie couverts par défaut : marquer ✅ « délégué à X » et lister les réglages à contrôler dans son dashboard (❓). Le code maison autour (routes de reset, profils, rôles) reste à auditer.

### AUTH-1 · Rate limiting sur connexion, inscription et reset — 🔴
- **Source** : [5failles] [20pts] · **Si** : `auth`
- **Pourquoi** : sans limite d'essais, un script teste des milliers de mots de passe (bruteforce) ou spamme l'envoi d'emails.
- **Vérifier** : sur les routes maison de login, signup, forgot-password et OTP : `express-rate-limit`, `@upstash/ratelimit`, `rate-limiter-flexible`, `@fastify/rate-limit`, `slowapi`, `django-ratelimit`, `ThrottlerModule` (Nest), ou règles WAF documentées (Vercel Firewall, Cloudflare). Fournisseur : ❓ limites dans son dashboard (Supabase : Authentication > Rate Limits).
- **Corriger** : limiter par IP et par identifiant (par exemple 5 essais par 15 minutes), avec un délai croissant.

### AUTH-2 · Même message pour email inconnu et mauvais mot de passe — 🟠
- **Source** : [5failles] [20pts] · **Si** : `auth` avec mot de passe
- **Pourquoi** : « aucun compte avec cet email » révèle qui est inscrit (énumération de comptes).
- **Vérifier** : Grep insensible à la casse dans le code d'auth et les fichiers de traduction : `user not found|no user|email not found|no account|account does not exist|wrong password|incorrect password|invalid password|utilisateur introuvable|aucun compte|mot de passe incorrect|email inconnu`. Même règle pour « mot de passe oublié » : la réponse est identique que l'email existe ou non.
- **Corriger** : un seul message (« Email ou mot de passe incorrect ») ; pour le reset : « Si un compte existe, un email a été envoyé ».

### AUTH-3 · Mots de passe hachés — 🔴
- **Source** : [5failles] [20pts] · **Si** : `auth` maison avec mot de passe
- **Pourquoi** : une base qui fuit avec des mots de passe lisibles compromet aussi les autres comptes de tes utilisateurs, qui réutilisent leurs mots de passe.
- **Vérifier** : présence de `bcrypt`, `argon2`, `scrypt`, `password_hash(` (PHP), `make_password` / `set_password` (Django), `passlib`. Signaux KO : colonne `password` écrite directement depuis la requête, `md5(`, `sha1(`, `createHash('sha256')` appliqué à un mot de passe, comparaison `===` avec la valeur en base.
- **Corriger** : argon2id ou bcrypt (coût ≥ 10), ou déléguer à un fournisseur d'auth.

### AUTH-4 · Sessions qui expirent et se révoquent — 🟠
- **Source** : [5failles] [20pts] · **Si** : `auth`
- **Pourquoi** : une session sans fin, une fois volée, reste valide pour toujours, même après suppression du compte ou changement de mot de passe.
- **Vérifier** : `jwt.sign(` sans `expiresIn`, cookies de session sans `maxAge` ni `expires`, `session.maxAge` (Auth.js), durée des tokens du fournisseur (Supabase : JWT expiry, 1 h par défaut). À la suppression du compte ou au changement de mot de passe, les sessions sont-elles invalidées (déconnexion globale, suppression des refresh tokens) ?
- **Corriger** : access token court (≤ 1 h) et refresh token rotatif, révocation à la suppression du compte et au changement de mot de passe.

### AUTH-5 · Email confirmé à l'inscription — 🟠
- **Source** : [20pts] · **Si** : inscription par email
- **Pourquoi** : sans confirmation, on crée des comptes au nom de n'importe qui, et les bots s'inscrivent en masse.
- **Vérifier** : Supabase : `supabase/config.toml`, section `[auth.email]`, `enable_confirmations = true` (sinon ❓ Authentication > Providers > Email > Confirm email) ; flux maison : token de vérification envoyé, et actions sensibles bloquées tant que l'email n'est pas vérifié.
- **Corriger** : activer la confirmation et restreindre l'accès tant que l'email n'est pas vérifié.

### AUTH-6 · Tokens et cookies de session protégés — 🟠
- **Source** : [compl.] · **Si** : `auth` et `web`
- **Pourquoi** : un token dans `localStorage` est lisible par n'importe quel script injecté (XSS) ; un cookie sans `SameSite` permet des requêtes forgées depuis un autre site (CSRF).
- **Vérifier** : `localStorage.setItem(` ou `sessionStorage` avec un token, un JWT ou une session ; cookies de session sans `httpOnly`, `secure`, `sameSite`. Les SDK Supabase et Firebase stockent en `localStorage` par défaut côté navigateur : acceptable si ACC-6 est propre, à noter en ⚠️. Auth par cookie et formulaires maison qui modifient des données : vérification de l'origine ou token CSRF (les Server Actions de Next vérifient l'origine d'elles-mêmes).
- **Corriger** : cookies `HttpOnly; Secure; SameSite=Lax` gérés côté serveur (par exemple `@supabase/ssr`).

---

## 4. ACC — Contrôle d'accès et données

### ACC-1 · Droits vérifiés côté serveur sur chaque route — 🔴
- **Source** : [5failles] [20pts] · **Si** : `api` (toute entrée serveur)
- **Pourquoi** : cacher un bouton ou vérifier dans le navigateur ne protège rien : on appelle l'API directement avec curl. C'est aussi là que l'accès « abonné » est souvent seulement masqué dans l'UI.
- **Vérifier** : lister toutes les entrées serveur (`app/**/route.ts`, `pages/api/**`, fonctions `'use server'`, routeurs Express / Fastify / Hono, `supabase/functions/*`, vues Django / FastAPI, dossier `api/` Vercel). Pour chacune :
  1. la session est-elle vérifiée ?
  2. la ressource appartient-elle à l'utilisateur (filtre sur l'id de la session, jamais sur un id pris dans la requête) ?
  3. le rôle ou l'abonnement est-il vérifié côté serveur pour les fonctions payantes ou admin ?
  Un `middleware.ts` seul ne suffit pas (il a déjà été contourné sur Next.js, CVE-2025-29927) : le contrôle doit aussi être dans la route.
- **Corriger** : un helper `requireUser()` / `requireRole()` appelé en tête de chaque route, et toutes les requêtes filtrées par propriétaire.

### ACC-2 · RLS activée (ou règles de sécurité) sur la base — 🔴
- **Source** : [20pts] · **Si** : `db` accessible depuis le client (Supabase, Firebase, PocketBase, Appwrite…)
- **Pourquoi** : avec la clé publique, n'importe qui lit toute table sans RLS. C'est le risque n°1 d'un SaaS vibe codé.
- **Vérifier** :
  - Supabase : dans `supabase/migrations/*.sql` (ou le schéma), chaque `create table` du schéma `public` a son `enable row level security` et des policies. Signaler `using (true)` ou `with check (true)` sur des données non publiques, les policies `update` sans `with check`, les vues et fonctions `security definer` exposées. Pas de migrations dans le repo → ❓ Supabase > Advisors > Security Advisor.
  - Firebase : `firestore.rules`, `storage.rules`, `database.rules.json` : KO si `allow read, write: if true`, ou si `request.auth != null` est la seule condition sur des données propres à chaque utilisateur.
  - Buckets de stockage publics qui contiennent des fichiers privés.
- **Corriger** : RLS partout, policies basées sur `auth.uid()`, et un test avec la clé anon qui prouve qu'on ne lit pas les données d'un autre compte.

### ACC-3 · Entrées validées côté serveur avant la base — 🔴
- **Source** : [20pts] · **Si** : routes qui écrivent ou requêtes SQL
- **Pourquoi** : injection SQL, champs inattendus (`role: "admin"`, `is_pro: true`), données corrompues.
- **Vérifier** :
  - un schéma de validation (zod, valibot, yup, joi, pydantic, class-validator) sur chaque route qui écrit ;
  - injection : SQL construit par concaténation ou interpolation (`${…}` dans une requête, `$queryRawUnsafe`, `execute(f"…")`, `"… " + req.`) ;
  - mass assignment : `update(req.body)`, ou `{...body}` passé tel quel à l'ORM.
- **Corriger** : schéma strict en liste blanche de champs, requêtes paramétrées, aucun champ de rôle ou d'abonnement modifiable par le client.

### ACC-4 · Uploads contrôlés (taille, type, stockage) — 🟠
- **Source** : [20pts] · **Si** : `upload`
- **Pourquoi** : un fichier énorme, c'est une facture ou un crash ; un `.html` ou un `.svg`, c'est du XSS ; un exécutable, c'est ton stockage qui héberge un malware.
- **Vérifier** : limite de taille côté serveur (`limits` de multer, `bodySizeLimit`, `file_size_limit` du bucket Supabase) ; type vérifié côté serveur (MIME + extension, idéalement la signature du fichier) : l'attribut `accept=` du `<input>` ne compte pas ; noms de fichiers générés par le serveur ; bucket privé et URLs signées pour les fichiers privés.
- **Corriger** : limites dans la route et dans le bucket (`allowed_mime_types`), renommage, SVG refusés ou assainis.

### ACC-5 · CORS configuré — 🟠
- **Source** : [20pts] · **Si** : `api` appelée depuis un navigateur
- **Pourquoi** : `*` laisse n'importe quel site appeler ton API ; avec des cookies, c'est avec les droits de l'utilisateur connecté.
- **Vérifier** : `Access-Control-Allow-Origin: *`, `cors()` sans options, `origin: true` (reflète toute origine) avec `credentials: true` ; `corsHeaders` à `'*'` dans des edge functions Supabase qui touchent des données privées.
- **Corriger** : liste blanche des domaines (prod + previews), jamais `*` avec credentials.

### ACC-6 · Pas de XSS par HTML injecté — 🔴
- **Source** : [compl.] · **Si** : `web`
- **Pourquoi** : un contenu utilisateur (ou généré par une IA) injecté en HTML exécute du JavaScript chez les autres visiteurs et vole leur session.
- **Vérifier** : `dangerouslySetInnerHTML`, `v-html`, `{@html`, `.innerHTML =`, `insertAdjacentHTML`, markdown rendu en HTML sans assainissement, sur des données qui ne viennent pas du code lui-même.
- **Corriger** : DOMPurify (ou `rehype-sanitize`) avant le rendu, sinon afficher en texte.

### ACC-7 · Pas de SSRF — 🟠
- **Source** : [compl.] · **Si** : le serveur télécharge une URL fournie par l'utilisateur (aperçu de lien, import, scraping, webhook sortant)
- **Pourquoi** : on fait lire au serveur des adresses internes (métadonnées du cloud, services privés).
- **Vérifier** : `fetch(`, `axios`, `got`, `requests.get(` sur une URL qui vient de la requête.
- **Corriger** : liste blanche de domaines, refus des IP privées et de localhost, pas de redirections suivies aveuglément.

### ACC-8 · Paiements décidés côté serveur — 🔴
- **Source** : [compl.] · **Si** : `paiement`
- **Pourquoi** : si le prix ou le plan vient du navigateur, on s'offre l'abonnement à 0,01 €.
- **Vérifier** : montant, prix ou plan lu depuis la requête (`amount: body.amount`, `unit_amount` calculé côté client, `priceId` non comparé à une liste connue) ; accès payant accordé à l'arrivée sur la `success_url` au lieu du webhook confirmé (PROD-3).
- **Corriger** : prix fixés côté serveur (price IDs en liste blanche), droits activés uniquement par le webhook signé.

### ACC-9 · Endpoints coûteux limités (IA, emails, SMS) — 🟠
- **Source** : [compl.] · **Si** : `ia`, ou envoi d'emails / SMS
- **Pourquoi** : un script qui boucle sur ta route IA vide ton crédit en une nuit.
- **Vérifier** : auth obligatoire, quota par utilisateur ou rate limit sur ces routes ; `max_tokens` borné ; ❓ plafond de dépense configuré chez le fournisseur.
- **Corriger** : rate limit + quota journalier par compte, plafond de facturation chez le fournisseur.

---

## 5. PROD — Mise en production et exploitation

### PROD-1 · Erreurs détaillées masquées en prod — 🟠
- **Source** : [20pts] · **Si** : toujours
- **Pourquoi** : une stack trace montre ta structure, tes requêtes SQL, parfois des secrets.
- **Vérifier** : réponses qui renvoient `err.message`, `err.stack`, `String(error)` ou l'erreur brute de la base au client ; `DEBUG = True` (Django), `debug=True` (Flask / FastAPI), endpoints de debug ou de test laissés en place (`/debug`, `/test`, `/admin` non protégé) ; absence de gestionnaire d'erreur global.
- **Corriger** : message générique et identifiant d'erreur côté client, détail uniquement dans les logs serveur.

### PROD-2 · Logs propres — 🟡 (🟠 si des secrets ou données personnelles sont loggés)
- **Source** : [20pts] · **Si** : toujours
- **Pourquoi** : les logs finissent dans des outils tiers ; mots de passe et tokens n'ont rien à y faire.
- **Vérifier** : `console.log`, `print`, `logger.*` de `req.body`, `password`, `token`, `authorization`, `headers`, `session`, d'un objet `user` complet ou d'une clé ; nombre de `console.log` de debug restants dans le code serveur.
- **Corriger** : retirer les logs de debug, masquer les champs sensibles, logger avec des niveaux (`info`, `error`).

### PROD-3 · Webhooks signés et idempotents — 🔴 si paiement, sinon 🟠
- **Source** : [20pts] (idempotence : [compl.]) · **Si** : `webhooks`
- **Pourquoi** : sans signature, n'importe qui envoie un faux « paiement réussi » à ton endpoint ; sans idempotence, un même événement renvoyé est traité deux fois.
- **Vérifier** : Stripe : `stripe.webhooks.constructEvent(rawBody, signature, secret)` sur le corps brut (pas après un `req.json()`) ; Lemon Squeezy, Paddle, GitHub, Clerk (svix), Resend : vérification HMAC de la signature ; secret du webhook en variable d'environnement ; `event.id` stocké pour ignorer les doublons.
- **Corriger** : vérifier la signature avant tout traitement, répondre 400 sinon, stocker les ids déjà traités.

### PROD-4 · Dépendances à jour et sans faille connue — 🟠
- **Source** : [20pts] (paquets hallucinés : [compl.]) · **Si** : toujours
- **Pourquoi** : une faille publique dans une dépendance est exploitée par des robots en quelques jours ; l'IA invente parfois des noms de paquets qu'un attaquant a enregistrés (slopsquatting).
- **Vérifier** : `npm audit --omit=dev` (ou `pnpm audit --prod`, `yarn npm audit`, `bun audit` ; `pip-audit` s'il est déjà installé) → compter les high et critical ; lockfile commité ; version du framework encore supportée. Paquets inconnus ou au nom proche d'un paquet connu : vérifier qu'ils existent et ont un vrai dépôt (`npm view <nom> repository homepage`).
- **Corriger** : `npm audit fix` (jamais `--force` sans relire), montées de version ciblées, suppression des paquets douteux.

### PROD-5 · Sauvegarde automatique de la base — 🟠
- **Source** : [20pts] · **Si** : `db`
- **Pourquoi** : une migration ratée, un agent trop zélé ou un bug de suppression, et tout disparaît.
- **Vérifier** : dans le code : cron ou GitHub Action de `pg_dump`, `mongodump`, copie du fichier SQLite. Sinon ❓ dans le dashboard de l'hébergeur (Supabase : Database > Backups ; les offres gratuites n'ont souvent pas de sauvegarde restaurable). Une restauration a-t-elle déjà été testée ?
- **Corriger** : sauvegarde quotidienne stockée hors de l'hébergeur principal, et un test de restauration.

### PROD-6 · Vérification automatique avant déploiement — 🟡
- **Source** : [usine] · **Si** : toujours
- **Pourquoi** : l'IA casse des choses loin de l'endroit où elle travaille ; sans build ni test, on le découvre en prod.
- **Vérifier** : scripts `build`, `lint`, `typecheck` (ou `tsc`), `test` dans `package.json` (ou équivalent) ; tests e2e (Playwright, Cypress) sur le parcours principal ; CI (`.github/workflows`) qui les lance. Lancer `build`, `lint`, `typecheck` et `test` s'ils existent et restent rapides, et noter les échecs.
- **Corriger** : au minimum build + typecheck en CI, et un test Playwright du parcours principal (inscription puis action clé).

### PROD-7 · Retour arrière possible — 🟡
- **Source** : [usine] · **Si** : `déployé`
- **Pourquoi** : « deploy sans rollback » fait partie des lignes rouges : si la prod casse, il faut pouvoir revenir en arrière en une minute.
- **Vérifier** : hébergeur avec rollback instantané (Vercel, Netlify, Cloudflare Pages…) ou déploiement versionné ; migrations réversibles, ou sauvegarde avant chaque migration (PROD-5).
- **Corriger** : écrire la procédure de rollback dans le `CLAUDE.md`.

### PROD-8 · En-têtes de sécurité HTTP — 🟡
- **Source** : [compl.] · **Si** : `web`
- **Pourquoi** : dix lignes de config bloquent des attaques entières (clickjacking, sniffing de type, retour en HTTP).
- **Vérifier** : `headers()` dans `next.config.*`, `vercel.json`, `netlify.toml` ou `_headers`, `helmet` (Express) : `Content-Security-Policy` (au moins `frame-ancestors`), `Strict-Transport-Security`, `X-Content-Type-Options: nosniff`, `Referrer-Policy`.
- **Corriger** : ajouter ces en-têtes, la CSP d'abord en mode report-only.

---

## 6. LEG — Légal FR/UE

L'audit repère ce qui manque ; il ne remplace pas un juriste. Les pages peuvent être rédigées par l'IA à partir de ce que le code utilise vraiment, puis relues.

### LEG-1 · Mentions légales — 🟠
- **Source** : [légal] (conformité au droit français) et [compl.] (LCEN) · **Si** : site public édité depuis la France
- **Pourquoi** : obligatoires en France pour tout site : identité de l'éditeur, contact, directeur de la publication, hébergeur.
- **Vérifier** : une page `mentions-legales`, `legal` ou `imprint`, liée dans le footer, qui nomme l'hébergeur (nom, adresse).
- **Corriger** : créer la page et la lier dans le footer.

### LEG-2 · Politique de confidentialité — 🟠
- **Source** : [légal] · **Si** : collecte de données personnelles (compte, formulaire, newsletter, analytics)
- **Pourquoi** : exigée par le RGPD dès qu'on collecte un email.
- **Vérifier** : une page dédiée, liée dans le footer et près des formulaires, qui cite les données collectées, les finalités, la durée de conservation, les droits (accès, suppression), un contact, et les sous-traitants **réellement utilisés dans le code** (Supabase, Vercel, Stripe, Resend, PostHog, fournisseur d'IA…) : comparer avec les dépendances et les appels d'API.
- **Corriger** : générer la page à partir de la liste réelle des services et des données du projet.

### LEG-3 · CGU, et CGV si vente — 🟠
- **Source** : [légal] · **Si** : comptes utilisateurs ou `vente`
- **Pourquoi** : elles fixent les règles d'usage, la responsabilité et la résiliation ; les CGV sont obligatoires pour vendre.
- **Vérifier** : pages `cgu` / `terms`, `cgv` en cas de paiement ; acceptation à l'inscription ou au paiement.
- **Corriger** : créer et lier les pages, case d'acceptation au paiement.

### LEG-4 · Cookies : bandeau de consentement si traceurs — 🟠
- **Source** : [légal] · **Si** : `web`
- **Pourquoi** : les traceurs non essentiels (analytics, pub) exigent un consentement préalable ; les déposer avant le consentement est une infraction.
- **Vérifier** : Grep des traceurs : `gtag|googletagmanager|google-analytics|fbq|connect\.facebook\.net|hotjar|clarity\.ms|posthog|mixpanel|segment|amplitude|ttq|analytics\.tiktok|snap\.licdn|intercom|crisp|hubspot`. S'il y en a : un bandeau (tarteaucitron, Axeptio, CookieYes, Klaro ou maison) qui **bloque** ces scripts avant le consentement, un bouton « Refuser » aussi visible qu'« Accepter », une page de politique de cookies. Analytics sans cookie (Plausible, Umami, Fathom, Vercel Analytics) : en général pas de bandeau nécessaire, mais à mentionner dans la politique de confidentialité.
- **Corriger** : charger les traceurs uniquement après consentement, ou passer à un analytics sans cookie.

### LEG-5 · Vente : rétractation, remboursement, consentement — 🟠
- **Source** : [légal] · **Si** : `vente` ou abonnement
- **Pourquoi** : le droit de rétractation de 14 jours s'applique en UE (avec une renonciation explicite possible pour un contenu numérique fourni immédiatement), et les processeurs de paiement attendent une politique de remboursement.
- **Vérifier** : une page remboursement ou rétractation ; cases de consentement non pré-cochées (CGV, newsletter) sur les formulaires ; renonciation explicite au droit de rétractation si l'accès est immédiat.
- **Corriger** : la page et des cases à cocher explicites.

### LEG-6 · Données minimisées et tracking audité — 🟡
- **Source** : [légal] · **Si** : collecte de données
- **Pourquoi** : chaque donnée collectée est une donnée à protéger, à déclarer, et qui peut fuiter.
- **Vérifier** : champs des formulaires et colonnes des tables (téléphone, date de naissance, adresse, IP…) : chacun sert-il une fonction réelle ? Tout le tracking listé en LEG-4 est-il utile et déclaré ?
- **Corriger** : supprimer les champs et traceurs inutiles.

### LEG-7 · Droits RGPD exerçables (suppression, export) — 🟡
- **Source** : [compl.] · **Si** : comptes utilisateurs
- **Pourquoi** : un utilisateur doit pouvoir supprimer son compte et ses données, ou au moins le demander simplement.
- **Vérifier** : une fonction « supprimer mon compte » (suppression en cascade des données et des fichiers, sessions révoquées comme en AUTH-4), ou un email de contact indiqué dans la politique de confidentialité.
- **Corriger** : ajouter la suppression de compte dans les réglages.

---

## 7. UI — Accessibilité et interface

### UI-1 · Textes alternatifs sur les images — 🟡
- **Source** : [légal] · **Si** : `web` ou `mobile`
- **Pourquoi** : les lecteurs d'écran et les agents IA ne voient pas l'image, seulement son texte alternatif.
- **Vérifier** : `<img` ou `<Image` sans `alt`, `alt` générique (`image`, `photo`, nom de fichier) ; les images décoratives ont `alt=""`.
- **Corriger** : un alt descriptif pour chaque image qui porte du sens.

### UI-2 · Contrastes lisibles — 🟡
- **Source** : [légal] [apple] · **Si** : interface
- **Pourquoi** : du gris clair sur blanc est illisible au soleil et pour les malvoyants.
- **Vérifier** : couleurs du thème (variables CSS, `tailwind.config`, tokens) : texte normal ≥ 4,5:1, gros texte et icônes ≥ 3:1. Suspects fréquents : `text-gray-400` ou `text-zinc-400` sur fond blanc (environ 2,5:1), placeholders, texte posé sur une image. Calculer le ratio quand les couleurs sont connues.
- **Corriger** : foncer les gris, ajouter un voile sous le texte posé sur une image.

### UI-3 · Structure lisible par les lecteurs d'écran et les agents IA — 🟡
- **Source** : [légal] · **Si** : `web`
- **Pourquoi** : lecteurs d'écran, moteurs de recherche et assistants IA lisent la structure de la page, pas son rendu visuel.
- **Vérifier** : un seul `<h1>` par page, `<title>` et meta description, `<html lang>`, balises `nav` / `main` / `footer`, `<button>` plutôt que `div onClick`, un `label` sur chaque champ de formulaire, contenu principal rendu côté serveur et pas seulement après exécution du JavaScript. Pour aller plus loin : skill `ai-seo` (llms.txt).
- **Corriger** : corriger la sémantique HTML et les labels.

### UI-4 · Cibles tactiles, espacements, hiérarchie — 🟡
- **Source** : [apple] · **Si** : interface utilisée sur mobile
- **Pourquoi** : les règles d'Apple (cibles ≥ 44 pt, contraste 4,5:1, espacements réguliers, hiérarchie claire) évitent les interfaces « presque bien » typiques du vibe coding. Le meilleur usage est d'auditer une UI existante, pas d'en générer une nouvelle.
- **Vérifier** : boutons, liens et icônes cliquables sous 44×44 px (`h-8 w-8`, `p-1` sur une icône), valeurs d'espacement arbitraires (`mt-[13px]`) et incohérentes, meta `viewport` présente, pas de scroll horizontal à 375 px. Audit plus poussé : skills `ui-ux-pro-max` ou `taste-skill` s'ils sont installés.
- **Corriger** : zone cliquable ≥ 44 px (par le padding), une seule échelle d'espacement.

---

## 8. CODE — Qualité du code

### CODE-1 · Pas de code gonflé — 🟡
- **Source** : [ponytail] · **Si** : toujours
- **Pourquoi** : l'IA empile les abstractions et les doublons ; le projet devient illisible et chaque modification en casse une autre.
- **Vérifier** : fichiers de plus de ~500 lignes, fonctions ou composants dupliqués, dépendances installées mais jamais importées, code mort, abstractions utilisées une seule fois, plusieurs bibliothèques pour le même besoin (deux libs de dates, deux clients HTTP). Si le skill `ponytail` est installé, s'appuyer sur sa revue (`/ponytail-review`).
- **Corriger** : lister les trois plus gros foyers et les simplifier dans une tâche dédiée, pas pendant l'audit.
