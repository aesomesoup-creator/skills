# -*- coding: utf-8 -*-
"""
Pousse la memoire de tous les projets Claude Code dans le vault Obsidian.

Source : ~/.claude/projects/<slug>/memory/*.md (les fiches memoire auto de Claude)
         + le CLAUDE.md du projet s'il existe
         + les projets des EXTRA_ROOTS (Drive d'un autre PC) : docs .md, package.json, git.
Cible  : <vault>/contextes/<projet>/  (une note d'index + une note par fiche)
         + <vault>/contextes/contextes.md (index de tous les projets).

Usage :
  python sync.py            synchronise et commit/push le vault (sortie lisible)
  python sync.py --auto     mode hook : throttle 30 min, s'execute detache, journal dans ~/.claude/vault-sync.log
  python sync.py --dry-run  montre ce qui changerait sans ecrire
"""
import datetime
import json
import os
import re
import subprocess
NOWIN = getattr(subprocess, 'CREATE_NO_WINDOW', 0)  # git sans fenetre console
import sys
import time

VAULT = os.environ.get('OBSIDIAN_VAULT', os.path.join(os.path.expanduser('~'), 'Documents', 'mon-vault'))
BRANCH = os.environ.get('OBSIDIAN_BRANCH', 'main')
PROJECTS = os.path.join(os.path.expanduser('~'), '.claude', 'projects')
DEST = 'contextes'
# Plusieurs machines ecrivent dans le meme vault. '' = le PC (contextes/<projet>/) ; sinon un
# suffixe (Mac : contextes/<projet>-mac/). Chaque machine a son manifeste et son index : aucune
# n'efface les notes d'une autre.
MACHINE = os.environ.get('VAULT_MACHINE', 'mac' if sys.platform == 'darwin' else '')
SUFFIX = f'-{MACHINE}' if MACHINE else ''
MANIFEST = os.path.join(DEST, f'.claude-sync{SUFFIX}.json')
INDEX_NAME = f'contextes{SUFFIX}'
STAMP = os.path.join(os.path.expanduser('~'), '.claude', 'vault-sync.last')
LOG = os.path.join(os.path.expanduser('~'), '.claude', 'vault-sync.log')
THROTTLE_S = 1800
# Projets a ignorer : le "projet" du dossier utilisateur lui-meme (slug = chemin, non-alphanumeriques -> '-')
_HOME_SLUG = re.sub(r'[^A-Za-z0-9]', '-', os.path.expanduser('~'))
SKIP_SLUGS = {_HOME_SLUG, _HOME_SLUG[:1].lower() + _HOME_SLUG[1:]}


# ── Resolution du chemin d'un projet depuis son slug ─────────────────────────
def resolve_path(slug: str):
    """'d--Users-<toi>-Desktop-APP' -> 'd:/Users/<toi>/Desktop/APP', et sur Mac
    '-Users-<toi>-Desktop-app' -> '/Users/<toi>/Desktop/app' (greedy sur les dossiers existants)."""
    m = re.match(r'^([A-Za-z])--(.*)$', slug)
    if m:
        path, rest = m.group(1) + ':/', m.group(2)
    elif slug.startswith('-'):
        path, rest = '/', slug[1:]
    else:
        return None
    tokens = rest.split('-')
    i = 0
    while i < len(tokens):
        seg = tokens[i]
        j = i + 1
        # Un nom contenant des tirets a ete decoupe : on re-agglutine tant que le dossier n'existe pas
        while not os.path.isdir(os.path.join(path, seg)) and j < len(tokens):
            seg = seg + '-' + tokens[j]
            j += 1
        if not os.path.isdir(os.path.join(path, seg)):
            return None
        path = os.path.join(path, seg)
        i = j
    return path.replace('\\', '/')


def project_name(slug: str, path):
    if path:
        return os.path.basename(path) or slug
    # Dossier disparu : on garde le slug sans son prefixe (c--Users-<toi>-Desktop-mon-app -> mon-app)
    base = re.sub(r'^[A-Za-z]--Users-[^-]+-Desktop-', '', slug)
    base = re.sub(r'^-(?:Users|home)-[^-]+-(?:Desktop-|Documents-)?', '', base)
    base = re.sub(r'^(claude-projects-|github-projects-)+', '', base)
    return base or slug


def folder_slug(name: str) -> str:
    s = re.sub(r'[^a-z0-9._-]+', '-', name.lower()).strip('-')
    return s or 'projet'


def read(p):
    with open(p, encoding='utf-8', errors='replace') as f:
        return f.read()


def frontmatter_desc(text: str) -> str:
    m = re.search(r'^description:\s*(.+)$', text, re.M)
    if not m:
        return ''
    return m.group(1).strip().strip('"\'')


def first_heading(text: str) -> str:
    m = re.search(r'^#\s+(.+)$', text, re.M)
    return m.group(1).strip() if m else ''


# ── Generation ───────────────────────────────────────────────────────────────
# Dossiers de projets supplementaires (ex : Drive synchronise depuis un autre PC).
# Chaque sous-dossier devient un projet : ses docs (.md) deviennent des fiches,
# package.json / git / arborescence alimentent la note d'index.
EXTRA_ROOTS = [r for r in os.environ.get(
    'VAULT_EXTRA_ROOTS',
    '',
).split(';') if r.strip()]
DOC_SKIP_DIRS = {'node_modules', '.git', 'dist', 'out', 'build', '.next', 'public', 'coverage', 'vendor', '.claude'}
DOC_MAX_FILES = 8
DOC_MAX_BYTES = 40_000
WIKILINK_ANY = re.compile(r'\[\[([^\]|]+)(?:\|([^\]]*))?\]\]')


def strip_wikilinks(text):
    """Les docs importees ne doivent pas creer de noeuds fantomes dans Obsidian."""
    return WIKILINK_ANY.sub(lambda m: (m.group(2) or m.group(1)).strip(), text)


def effective_dir(d):
    """'portfolio/mon-portfolio' : si le dossier ne contient qu'un sous-dossier, on descend."""
    for _ in range(2):
        try:
            entries = [e for e in os.listdir(d) if not e.startswith('.')]
        except OSError:
            return d
        subdirs = [e for e in entries if os.path.isdir(os.path.join(d, e))]
        files = [e for e in entries if os.path.isfile(os.path.join(d, e))]
        if len(subdirs) == 1 and not files and not os.path.isdir(os.path.join(d, '.git')):
            d = os.path.join(d, subdirs[0])
        else:
            break
    return d


def scan_docs(d):
    """Fichiers .md a profondeur <= 2, hors dossiers techniques. Retourne [(rel, text, mtime)]."""
    found = []
    for root, dirs, fnames in os.walk(d):
        depth = os.path.relpath(root, d).count(os.sep) + (0 if root == d else 1)
        dirs[:] = sorted(x for x in dirs if x not in DOC_SKIP_DIRS and not x.startswith('.')) if depth < 2 else []
        for f in sorted(fnames):
            if not f.lower().endswith('.md') or f == 'MEMORY.md':
                continue
            abs_p = os.path.join(root, f)
            try:
                if os.path.getsize(abs_p) > DOC_MAX_BYTES:
                    continue
                text = read(abs_p)
            except OSError:
                continue
            if len(text.strip()) < 20:
                continue
            rel = os.path.relpath(abs_p, d).replace('\\', '/')
            found.append((rel, text, os.path.getmtime(abs_p)))
    # racine d'abord, puis les plus gros
    found.sort(key=lambda x: (x[0].count('/'), -len(x[1])))
    return found[:DOC_MAX_FILES]


def git_info(d):
    if not os.path.isdir(os.path.join(d, '.git')):
        return None
    try:
        last = subprocess.run(['git', '-C', d, 'log', '-1', '--date=short', '--format=%ad|%s'],
                              capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=20, creationflags=NOWIN).stdout.strip()
        count = subprocess.run(['git', '-C', d, 'rev-list', '--count', 'HEAD'],
                               capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=20, creationflags=NOWIN).stdout.strip()
    except Exception:
        return None
    if not last:
        return None
    date, _, msg = last.partition('|')
    return {'date': date, 'msg': msg.strip(), 'count': count or '?'}


def pkg_info(d):
    pj = os.path.join(d, 'package.json')
    if not os.path.isfile(pj):
        return None
    try:
        data = json.loads(read(pj))
    except Exception:
        return None
    return {
        'name': data.get('name') or '',
        'description': data.get('description') or '',
        'deps': sorted((data.get('dependencies') or {}).keys())[:15],
        'scripts': sorted((data.get('scripts') or {}).keys())[:8],
    }


def doc_fname(rel, taken):
    base = os.path.splitext(os.path.basename(rel))[0].lower()
    base = re.sub(r'[^a-z0-9]+', '-', base).strip('-') or 'doc'
    if base == 'claude':
        base = 'claude-md'
    if base == 'graph-report':
        base = 'graphe-code'
    name, i = base, 2
    while name in taken:
        name, i = f'{base}-{i}', i + 1
    taken.add(name)
    return name


def scan_extra_project(d):
    """Retourne un dict decrivant un projet trouve dans un EXTRA_ROOT, ou None s'il est vide."""
    d = effective_dir(d)
    docs = scan_docs(d)
    git = git_info(d)
    pkg = pkg_info(d)
    try:
        tree = sorted(e for e in os.listdir(d) if e not in DOC_SKIP_DIRS and not e.startswith('.'))[:24]
    except OSError:
        tree = []
    if not docs and not git and not pkg and not tree:
        return None
    latest = max([m for _, _, m in docs] + [0.0])
    if git and git['date']:
        try:
            latest = max(latest, datetime.datetime.strptime(git['date'], '%Y-%m-%d').timestamp())
        except ValueError:
            pass
    return {'path': d.replace('\\', '/'), 'docs': docs, 'git': git, 'pkg': pkg, 'tree': tree, 'updated': latest}


def new_project(name, folder):
    return {'name': name, 'folder': folder, 'paths': [], 'fiches': [], 'docs': [], 'claude_md': False,
            'updated': 0.0, 'sources': set(), 'extra': None, 'notes': 0}


def build():
    """Retourne (files: dict path->content, projects: list) — chemins relatifs au vault."""
    files = {}
    projects = {}
    today = datetime.date.today().isoformat()

    # 1) Memoire des projets Claude Code de cette machine
    if os.path.isdir(PROJECTS):
        for slug in sorted(os.listdir(PROJECTS)):
            if slug in SKIP_SLUGS:
                continue
            mem_dir = os.path.join(PROJECTS, slug, 'memory')
            if not os.path.isdir(mem_dir):
                continue
            notes = sorted(f for f in os.listdir(mem_dir) if f.endswith('.md') and f != 'MEMORY.md')
            if not notes:
                continue
            path = resolve_path(slug)
            name = project_name(slug, path)
            folder = folder_slug(name) + SUFFIX
            pr = projects.setdefault(folder, new_project(name, folder))
            pr['sources'].add('memoire')
            if path:
                pr['paths'].append(path)
            base = f'{DEST}/{folder}'
            for n in notes:
                src = os.path.join(mem_dir, n)
                text = read(src)
                pr['updated'] = max(pr['updated'], os.path.getmtime(src))
                files[f'{base}/{n}'] = text
                pr['fiches'].append((n[:-3], first_heading(text) or n[:-3], frontmatter_desc(text)))
                pr['notes'] += 1
            # Consignes du projet : AGENTS.md (lu par tous les agents) prime quand CLAUDE.md
            # est absent ou n'est qu'un renvoi "@AGENTS.md".
            claude_md = os.path.join(path, 'CLAUDE.md') if path else None
            agents_md = os.path.join(path, 'AGENTS.md') if path else None
            src_md, src_label = None, 'CLAUDE.md'
            if claude_md and os.path.isfile(claude_md):
                src_md = claude_md
                if agents_md and os.path.isfile(agents_md):
                    pointer = read(claude_md).strip()
                    if len(pointer) < 200 and '@AGENTS.md' in pointer:
                        src_md, src_label = agents_md, 'AGENTS.md'
            elif agents_md and os.path.isfile(agents_md):
                src_md, src_label = agents_md, 'AGENTS.md'
            if src_md:
                files[f'{base}/claude-md.md'] = (
                    '---\ntype: claude-md\nprojet: ' + json.dumps(name) + '\n---\n\n'
                    f'# {src_label} — {name}\n\nInstructions du projet telles que lues par Claude Code.\n\n'
                    + read(src_md)
                )
                pr['claude_md'] = True

    # 2) Projets des dossiers supplementaires (Drive d'un autre PC, etc.)
    for root in EXTRA_ROOTS:
        if not os.path.isdir(root):
            continue
        for entry in sorted(os.listdir(root)):
            d = os.path.join(root, entry)
            if entry.startswith('.') or not os.path.isdir(d):
                continue
            info = scan_extra_project(d)
            if not info:
                continue
            folder = folder_slug(entry) + SUFFIX
            pr = projects.setdefault(folder, new_project(entry, folder))
            pr['sources'].add('drive')
            pr['paths'].append(info['path'])
            pr['extra'] = info
            pr['updated'] = max(pr['updated'], info['updated'])
            base = f'{DEST}/{folder}'
            taken = {os.path.basename(k)[:-3] for k in files if k.startswith(base + '/')}
            for rel, text, mtime in info['docs']:
                fname = doc_fname(rel, taken)
                title = first_heading(text) or os.path.basename(rel)
                body = strip_wikilinks(text)
                files[f'{base}/{fname}.md'] = (
                    '---\ntype: doc-projet\nprojet: ' + json.dumps(entry) + '\nfichier: ' + json.dumps(rel)
                    + '\nsource: drive\n---\n\n' + body
                )
                pr['docs'].append((fname, title, rel))
                pr['notes'] += 1

    # 3) Une note d'index par projet
    out = []
    for folder, pr in sorted(projects.items()):
        name, base = pr['name'], f'{DEST}/{folder}'
        updated = datetime.datetime.fromtimestamp(pr['updated']).strftime('%Y-%m-%d') if pr['updated'] else today
        src_label = ' + '.join(sorted(pr['sources']))
        idx = [
            '---',
            'type: contexte-claude',
            'projet: ' + json.dumps(name),
            'chemin: ' + json.dumps(pr['paths'][0] if pr['paths'] else ''),
            f'notes: {pr["notes"]}',
            f'maj: {updated}',
            f'source: {src_label}',
            '---',
            '',
            f'# {name}',
            '',
            f'Contexte du projet `{name}` — {pr["notes"]} note{"s" if pr["notes"] > 1 else ""}, dernière mise à jour le {updated}, source : {src_label}.',
            f'Synchronisé automatiquement — ne pas éditer ici. [[{INDEX_NAME}|tous les projets]]',
            '',
        ]
        if pr['paths']:
            idx += ['## Emplacements', ''] + [f'- `{p}`' for p in pr['paths']] + ['']
        if pr['fiches']:
            idx += ['## Fiches mémoire (Claude Code)', '']
            for fname, title, desc in pr['fiches']:
                idx.append(f'- [[{base}/{fname}|{title}]]' + (f' — {desc}' if desc else ''))
            idx.append('')
        if pr['claude_md']:
            idx += ['## Instructions', '', f'- [[{base}/claude-md|CLAUDE.md du projet]]', '']
        ex = pr['extra']
        if ex:
            idx += ['## Dossier synchronisé (Drive)', '']
            if ex['pkg']:
                pk = ex['pkg']
                if pk['description']:
                    idx.append(f'- Description : {pk["description"]}')
                if pk['deps']:
                    idx.append('- Stack : ' + ', '.join(f'`{x}`' for x in pk['deps']))
                if pk['scripts']:
                    idx.append('- Scripts npm : ' + ', '.join(f'`{x}`' for x in pk['scripts']))
            if ex['git']:
                g = ex['git']
                idx.append(f'- Git : {g["count"]} commits, dernier le {g["date"]} — « {g["msg"]} »')
            if ex['tree']:
                idx.append('- Arborescence : ' + ' '.join(f'`{x}`' for x in ex['tree']))
            idx.append('')
            if pr['docs']:
                idx += ['### Documents', '']
                for fname, title, rel in pr['docs']:
                    idx.append(f'- [[{base}/{fname}|{title}]] — `{rel}`')
                idx.append('')
        files[f'{base}/{folder}.md'] = '\n'.join(idx)
        out.append({'name': name, 'folder': folder, 'notes': pr['notes'], 'updated': updated,
                    'path': pr['paths'][0] if pr['paths'] else '', 'source': src_label})

    # 4) Index global
    title = '# Contextes des projets' + (f' ({MACHINE})' if MACHINE else '')
    lines = ['---', 'type: index', 'source: claude-code', f'maj: {today}', '---', '', title, '',
             f'{len(out)} projet{"s" if len(out) > 1 else ""}. Chaque dossier contient la mémoire que Claude a constituée en travaillant sur le projet (décisions, architecture, préférences, avancement) et/ou les docs du projet lui-même (README, CLAUDE.md, rapports). Regénéré par le skill `vault-sync`.', '',
             '| Projet | Notes | Maj | Source |', '|---|---|---|---|']
    for p in sorted(out, key=lambda p: p['updated'], reverse=True):
        lines.append(f'| [[{DEST}/{p["folder"]}/{p["folder"]}|{p["name"]}]] | {p["notes"]} | {p["updated"]} | {p["source"]} |')
    lines.append('')
    # Les index des autres machines (contextes.md = PC, contextes-mac.md = Mac...)
    try:
        others = sorted(f[:-3] for f in os.listdir(os.path.join(VAULT, DEST))
                        if re.fullmatch(r'contextes(-[\w.-]+)?\.md', f) and f[:-3] != INDEX_NAME)
    except OSError:
        others = []
    if others:
        lines += ['Autres machines : ' + ', '.join(f'[[{DEST}/{o}|{o}]]' for o in others), '']
    files[f'{DEST}/{INDEX_NAME}.md'] = '\n'.join(lines)
    return files, out


# ── Carte du vault pour les agents ───────────────────────────────────────────
WIKILINK = re.compile(r'\[\[([^\]|#]+)(?:#[^\]|]*)?(?:\|[^\]]*)?\]\]')
SKIP_DIRS = {'.git', '.obsidian', '.trash', 'node_modules'}

def note_meta(abs_p):
    text = read(abs_p)
    body = re.sub(r'^---\n.*?\n---\n', '', text, count=1, flags=re.S)
    title = first_heading(body) or os.path.splitext(os.path.basename(abs_p))[0]
    desc = frontmatter_desc(text)
    if not desc:
        for line in body.splitlines():
            s = line.strip()
            if s and not s.startswith('#') and not s.startswith('---') and not s.startswith('|'):
                desc = re.sub(r'\s+', ' ', s)
                break
    desc = desc.replace('\n', ' ')[:140]
    links = []
    for m in WIKILINK.finditer(body):
        t = m.group(1).strip()
        if t and t not in links:
            links.append(t)
    return title, desc, links


def build_vault_map(generated):
    """vault-index.md : une ligne par note (chemin, titre, resume, liens sortants), groupees par dossier.
    Lue en premier par les agents : ~4k tokens au lieu de tout le repo."""
    notes = []
    for root, dirs, fnames in os.walk(VAULT):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS)
        for f in sorted(fnames):
            if not f.endswith('.md'):
                continue
            abs_p = os.path.join(root, f)
            rel = os.path.relpath(abs_p, VAULT).replace('\\', '/')
            if rel == 'vault-index.md':
                continue
            try:
                title, desc, links = note_meta(abs_p)
                mtime = datetime.datetime.fromtimestamp(os.path.getmtime(abs_p)).strftime('%Y-%m-%d')
            except OSError:
                continue
            notes.append((rel, title, desc, links, mtime))
    by_dir = {}
    for rel, title, desc, links, mtime in notes:
        top = rel.split('/')[0] if '/' in rel else '(racine)'
        by_dir.setdefault(top, []).append((rel, title, desc, links, mtime))
    lines = [
        '---', 'type: index', 'source: vault-sync', f'maj: {datetime.date.today().isoformat()}', f'notes: {len(notes)}', '---', '',
        '# Carte du vault',
        '',
        'Lis cette carte AVANT d\'ouvrir des notes : une ligne par note avec son chemin, son titre, son résumé et les notes qu\'elle cite.',
        'Choisis 1 à 3 notes pertinentes et lis-les ; ne parcours jamais le vault entier. Pour un mot précis, préfère une recherche (grep).',
        '',
        '| Dossier | Rôle | Écrit par |',
        '|---|---|---|',
        '| `contextes/` | mémoire de chaque projet Claude Code | les Claude Code (auto) |',
        '| `projets/` | notes de projets rédigées à la main | toi / Claude |',
        '| `inbox/` | captures à trier | tout le monde |',
        '',
    ]
    for top in sorted(by_dir):
        lines.append(f'## {top}')
        lines.append('')
        for rel, title, desc, links, mtime in by_dir[top]:
            link_s = (' → ' + ', '.join(f'[[{l}]]' for l in links[:6]) + (' …' if len(links) > 6 else '')) if links else ''
            lines.append(f'- `{rel}` — **{title}** ({mtime}){(" — " + desc) if desc else ""}{link_s}')
        lines.append('')
    return '\n'.join(lines)

# ── Ecriture + git ───────────────────────────────────────────────────────────
def git(*args, check=True):
    return subprocess.run(['git', '-C', VAULT, *args], capture_output=True, text=True, encoding='utf-8', errors='replace', check=check, creationflags=NOWIN)


def pull_rebase():
    """pull --rebase. vault-index.md est recalcule par chaque machine a chaque passe : un conflit sur
    ce seul fichier (deux machines qui poussent en meme temps) se regle en gardant le notre, qui sera
    recalcule juste apres. Tout autre conflit annule le rebase, comme avant."""
    r = git('pull', '--rebase', '--autostash', '-q', 'origin', BRANCH, check=False)
    for _ in range(10):
        if r.returncode == 0:
            return r
        conflicts = set(git('diff', '--name-only', '--diff-filter=U', check=False).stdout.split())
        if not conflicts or conflicts - {'vault-index.md'}:
            break
        git('checkout', '--theirs', 'vault-index.md')  # pendant un rebase, --theirs = notre commit
        git('add', 'vault-index.md')
        r = git('-c', 'core.editor=true', 'rebase', '--continue', check=False)
    git('rebase', '--abort', check=False)
    return r


def refresh_vault_map():
    """Recalcule vault-index.md sur l'etat du disque. True s'il a change."""
    vmap = build_vault_map(None)
    vmap_path = os.path.join(VAULT, 'vault-index.md')
    if os.path.isfile(vmap_path) and read(vmap_path) == vmap:
        return False
    with open(vmap_path, 'w', encoding='utf-8', newline='\n') as f:
        f.write(vmap)
    return True


def wait_index_lock():
    lock = os.path.join(VAULT, '.git', 'index.lock')
    for _ in range(20):
        if not os.path.exists(lock):
            return True
        time.sleep(0.5)
    return False


# ── Garde-fou : aucun secret ne part dans le vault ───────────────────────────
# Le vault est pousse sur GitHub : une fiche memoire qui contiendrait un jeton par
# erreur est nettoyee AVANT ecriture, et la synchro le signale dans le journal.
SECRET_RE = re.compile('|'.join(f'(?:{p})' for p in (
    r'(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{36,}',
    r'github_pat_[A-Za-z0-9_]{50,}',
    r'sk-ant-[A-Za-z0-9_\-]{20,}',
    r'(?<![A-Za-z0-9_\-])sk-(?:proj-|or-v1-)?(?=[A-Za-z0-9_\-]*\d)[A-Za-z0-9_\-]{32,}',
    r'shp(?:at|ss|ca|pa)_[a-fA-F0-9]{32}',
    r'EAA[A-Za-z0-9]{60,}',
    r'AKIA[0-9A-Z]{16}',
    r'xox[baprs]-[A-Za-z0-9\-]{10,}',
    r'-----BEGIN [A-Z ]*PRIVATE KEY-----',
    r'eyJ[A-Za-z0-9_\-]{15,}\.eyJ[A-Za-z0-9_\-]{30,}\.[A-Za-z0-9_\-]{10,}',
    r'pat[A-Za-z0-9]{14}\.[a-f0-9]{64}',
    r'apify_api_[A-Za-z0-9]{30,}',
    r'(?:sk|rk)_(?:live|test)_[A-Za-z0-9]{16,}',        # Stripe
    r'whsec_[A-Za-z0-9+/=]{20,}',                        # Stripe, webhooks
    r'AIza[0-9A-Za-z_\-]{35}',                          # Google
    r'(?<![\w:])\d{8,10}:AA[0-9A-Za-z_\-]{30,}',        # bot Telegram
    r'sbp_[a-f0-9]{40}',                                 # Supabase, jeton personnel
    r'sb_secret_[A-Za-z0-9_\-]{20,}',                    # Supabase, cle secrete
    r're_[A-Za-z0-9]{8,}_[A-Za-z0-9]{16,}',              # Resend
)))
# Une valeur affectee a un nom qui dit « mot de passe / secret / jeton / cle » (DB_PASSWORD=...,
# x-admin-password: ...). Seule la valeur est retiree ; les renvois (<...>, ${...}) passent.
ASSIGN_SECRET_RE = re.compile(
    r'''(?i)(\b[\w-]*(?:password|passwd|pwd|secret|token|api[_-]?key)[\w-]*["']?\s*(?:=|:\s*)["']?)'''
    r'''(?![<${])(?!\d+\b)(?!(?:process\.env|import\.meta|os\.environ|secrets|env|vars)\.)([^\s"'`<>,;)]{8,})''')
SECRET_MARK = '[SECRET RETIRE PAR VAULT-SYNC]'


def redact_secrets(files):
    """Remplace tout ce qui ressemble a un jeton. Retourne [(note, nombre)] pour le journal."""
    hits = []
    for rel, content in files.items():
        cleaned, n = SECRET_RE.subn(SECRET_MARK, content)
        cleaned, m = ASSIGN_SECRET_RE.subn(lambda x: x.group(1) + SECRET_MARK, cleaned)
        n += m
        if n:
            files[rel] = cleaned
            hits.append((rel, n))
    return hits


def apply(files, dry_run=False):
    manifest_path = os.path.join(VAULT, MANIFEST)
    try:
        old = set(json.load(open(manifest_path, encoding='utf-8')))
    except Exception:
        old = set()
    written = 0
    for rel, content in files.items():
        abs_p = os.path.join(VAULT, rel)
        if os.path.isfile(abs_p) and read(abs_p) == content:
            continue
        written += 1
        if dry_run:
            print('  ~', rel)
            continue
        os.makedirs(os.path.dirname(abs_p), exist_ok=True)
        with open(abs_p, 'w', encoding='utf-8', newline='\n') as f:
            f.write(content)
    removed = 0
    for rel in sorted(old - set(files)):
        abs_p = os.path.join(VAULT, rel)
        if os.path.isfile(abs_p):
            removed += 1
            if dry_run:
                print('  -', rel)
            else:
                os.remove(abs_p)
    if not dry_run:
        os.makedirs(os.path.dirname(manifest_path), exist_ok=True)
        with open(manifest_path, 'w', encoding='utf-8', newline='\n') as f:
            json.dump(sorted(files), f, indent=1)
        # Dossiers de projets devenus vides (projet renomme ou disparu)
        dest_abs = os.path.join(VAULT, DEST)
        for d in os.listdir(dest_abs):
            p = os.path.join(dest_abs, d)
            if os.path.isdir(p) and not os.listdir(p):
                os.rmdir(p)
    return written, removed


def main():
    args = set(sys.argv[1:])
    dry_run = '--dry-run' in args
    auto = '--auto' in args

    if auto:
        # Throttle : au plus une synchro toutes les 30 minutes
        try:
            if time.time() - os.path.getmtime(STAMP) < THROTTLE_S:
                return 0
        except OSError:
            pass
        if '--detached' not in args:
            # Ne pas bloquer Claude : on se relance en arriere-plan et on rend la main
            flags = 0
            if os.name == 'nt':
                flags = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
            with open(LOG, 'a', encoding='utf-8') as log:
                subprocess.Popen([sys.executable, os.path.abspath(__file__), '--auto', '--detached'],
                                 stdout=log, stderr=log, stdin=subprocess.DEVNULL, creationflags=flags, close_fds=True,
                                 start_new_session=(os.name != 'nt'))
            return 0
        open(STAMP, 'w').close()

    if not os.path.isdir(os.path.join(VAULT, '.git')):
        print(f'Vault introuvable : {VAULT}')
        return 1
    missing_roots = [r for r in EXTRA_ROOTS if not os.path.isdir(r)]
    if missing_roots:
        # Sans le Drive, on retirerait tous ses projets du vault puis on les remettrait : on reporte plutot.
        print('Synchro reportee, dossier de projets inaccessible (Drive non monte ?) : ' + ' ; '.join(missing_roots))
        return 1

    if not dry_run:
        if not wait_index_lock():
            print('Le vault est occupe (index.lock) — reessaie dans un instant.')
            return 1
        pull = pull_rebase()
        if pull.returncode != 0:
            print('Pull impossible :', (pull.stderr or pull.stdout).strip()[:300])
            return 1

    files, projects = build()
    for rel, n in redact_secrets(files):
        print(f'ATTENTION : {n} secret(s) retire(s) de {rel} avant ecriture. Corrige la fiche source.')
    written, removed = apply(files, dry_run)
    # Carte du vault : calculee sur l'etat du disque (contextes et les autres notes du vault)
    if not dry_run and refresh_vault_map():
        written += 1
    stamp = datetime.datetime.now().strftime('%d/%m %H:%M')
    print(f'[{stamp}] {len(projects)} projets, {len(files)} notes generees, {written} ecrites, {removed} retirees')
    if dry_run or (written == 0 and removed == 0):
        if not dry_run:
            print('Rien a pousser : le vault est deja a jour.')
        return 0

    git('add', '-A', DEST, 'vault-index.md')
    status = git('status', '--porcelain', DEST, 'vault-index.md').stdout.strip()
    if not status:
        print('Rien a commiter (deja pris en charge par Obsidian).')
        return 0
    msg = f'Claude Code : contextes du {datetime.datetime.now().strftime("%d %B %H:%M")}'
    git('commit', '-q', '-m', msg)
    for _ in range(3):
        push = git('push', '-q', 'origin', BRANCH, check=False)
        if push.returncode == 0:
            break
        # Une autre machine a pousse entre-temps : on rejoue notre commit par-dessus le sien,
        # puis on recalcule la carte sur l'etat fusionne.
        if pull_rebase().returncode != 0:
            break
        if refresh_vault_map():
            git('add', 'vault-index.md')
            git('commit', '-q', '-m', 'Claude Code : carte du vault')
    if push.returncode != 0:
        print('Commit fait mais push impossible :', (push.stderr or push.stdout).strip()[:300])
        return 1
    print(f'Pousse sur {BRANCH} : "{msg}"')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except subprocess.CalledProcessError as e:
        print('Erreur git :', (e.stderr or e.stdout or str(e)).strip()[:400])
        sys.exit(1)
