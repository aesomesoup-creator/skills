# model-regulator : Fable 5 seulement quand ça vaut le coup

Régulateur de modèle pour Claude Code. Ta session tourne sous Opus. Avant chaque prompt, un hook
décide si le prompt mérite Fable 5 :
- **sous Opus** : si oui, Opus délègue automatiquement le cœur difficile à un sous-agent Fable ;
- **sous Fable** : pour les broutilles, une fenêtre propose de repasser sur Opus.

| Dossier / fichier | Rôle |
|---|---|
| `skills/model-regulator/` | le hook `regulator.py`, ses tests et `/model-regulator` (pilotage, règles, réglages) |
| `agents/fable-worker.md`, `agents/fable-deep.md` | les sous-agents Fable (effort high / xhigh) |
| `skills/fable-boost/` | `/fable-boost <demande>` : raccourci manuel, efficacité non vérifiée |
| `install.py` | installe le tout dans `~/.claude/` |

Données locales : `~/.claude-regulator/`.

## Installation (Mac, Windows, Linux)

Il te faut Claude Code et Python 3. Dans ce dossier, une fois le zip ouvert :

```bash
python3 install.py --dry-run   # montre ce qui va changer
python3 install.py             # Windows : python install.py
```

Le script copie les skills et les agents dans `~/.claude/`, ajoute le hook dans
`~/.claude/settings.json` avec l'interpréteur Python qui l'a lancé, met le modèle par défaut sur
`opus[1m]` et l'effort Fable sur `high`. Une sauvegarde `settings.json.bak-model-regulator` est créée.
Pour mettre à jour, télécharge le nouveau zip et relance-le. Ouvre ensuite une nouvelle session.

- **Fenêtre Oui/Non** : Windows (boîte système) et macOS (`osascript`). Sous Linux, pas de fenêtre :
  mets `"ui": "block"` ou `"warn"` dans `~/.claude-regulator/config.json`.
- **Quota Fable** : il est lu dans une base locale (`~/.claude-pace/pace.db`) que ce paquet ne
  fournit pas. Sans elle, les seuils restent ceux de base, sans ajustement au rythme ni coupure à 97 %.

## Pourquoi une délégation et pas un vrai changement de modèle

Testé le 2026-09-21 :
- un hook ne peut pas changer le modèle de la session ;
- le `model:` d'un skill invoqué par Claude est ignoré : l'API a continué de servir Opus, alors même
  que Claude Code annonçait Fable ;
- un sous-agent lancé avec `model: fable` est bien servi par `claude-fable-5-1`.

Un sous-agent ne voit pas la conversation. Le hook écrit donc l'historique (prompts et réponses, sans
les sorties d'outils) dans `~/.claude-regulator/context/<session>.md`, et le sous-agent le lit en premier.

## Combien il délègue

Avec une base de quota, le seuil s'adapte à ton rythme de consommation Fable, avec pour cible 95 %
du quota hebdo au reset : il délègue davantage quand tu es en retard sur ce rythme et moins quand
tu es en avance. Mesuré sur 584 prompts réels (14 jours), la part jugée « Fable » va de 9 % (seuil
le plus haut) à 28 % (seuil le plus bas). `/model-regulator` affiche le seuil en vigueur.

Détail des règles et des réglages : voir `SKILL.md`.
