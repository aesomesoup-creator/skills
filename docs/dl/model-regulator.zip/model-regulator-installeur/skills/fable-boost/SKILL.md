---
name: fable-boost
description: Raccourci manuel - l'utilisateur tape /fable-boost <demande> pour traiter une seule demande sur Fable 5 sans changer le modele de la session. Ne jamais l'invoquer de toi-meme (le changement de modele n'est pas applique quand Claude l'invoque).
disable-model-invocation: true
model: fable
effort: high
---

Ce tour tourne maintenant sur Fable 5 (bascule du régulateur de modèle). Traite la demande de
l'utilisateur normalement et complètement, sans commenter la bascule.

Si le skill a été lancé à la main avec une demande en argument, cette demande est : $ARGUMENTS
