#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""model-regulator — Fable 5 ou Opus pour ce prompt ?

Hook UserPromptSubmit de Claude Code. Note chaque prompt avec des heuristiques
locales (zero token, zero reseau) et le compare au modele de base de la session.

Un hook ne peut pas changer le modele de la session, et le `model:` d'un skill
invoque par Claude est ignore (teste le 2026-09-21 : l'API sert toujours Opus).
Seuls les sous-agents tournent vraiment sur un autre modele. D'ou :
mode "auto" (defaut), session sous Opus : un prompt qui merite Fable est
  delegue a un sous-agent Fable (~/.claude/agents/fable-worker.md, effort high,
  ou fable-deep.md, effort xhigh). Opus garde la conversation et verifie.
mode "ask", et session sous Fable dans tous les modes : propose un /model par
  boite de dialogue et stoppe le prompt si oui.

Ne doit JAMAIS casser un prompt : toute erreur => exit 0 silencieux.
Stdlib uniquement. Lecture seule sur ~/.claude et ~/.claude-pace.

  regulator.py hook              stdin = JSON du hook
  regulator.py test "<prompt>"   verdict a blanc, sans effet de bord
  regulator.py status | stats | on | off
"""
import json
import os
import re
import sqlite3
import subprocess
import sys
import time
import unicodedata

HOME = os.path.expanduser("~")
DATA_DIR = os.path.join(HOME, ".claude-regulator")
CONFIG_PATH = os.path.join(DATA_DIR, "config.json")
LOG_PATH = os.path.join(DATA_DIR, "log.jsonl")
STATE_DIR = os.path.join(DATA_DIR, "state")
LAST_PROMPT_PATH = os.path.join(DATA_DIR, "last_blocked_prompt.txt")
SETTINGS_PATH = os.path.join(HOME, ".claude", "settings.json")
SETTINGS_SEEN_PATH = os.path.join(DATA_DIR, "settings_model.json")
PACE_DB = os.path.join(HOME, ".claude-pace", "pace.db")

DEFAULT_CONFIG = {
    "enabled": True,
    "mode": "auto",           # auto (Opus delegue le dur a un sous-agent Fable) | ask (propose un /model)
    "ui": "dialog",           # mode ask : dialog | block | warn
    "fable_min": 4,           # score >= : le prompt merite Fable (avant ajustement au rythme ; 3 avant le 24/09)
    "trivial_max": -2,        # score <= : broutille
    "deep_min": 8,            # score >= : Fable en effort xhigh (sous-agent fable-deep)
    "pace_target_pct": 95,    # quota Fable vise au reset hebdo : les seuils bougent pour y arriver
    "context_chars": 120000,  # historique transmis au sous-agent (~30k tokens)
    "cooldown": 4,            # sous Fable : broutille = 2 pts, standard = 1 pt
    "snooze_min": 20,         # apres un refus, ne redemande pas avant
    "grace_min": 10,          # apres un stop, le prompt suivant passe toujours
    "dialog_timeout_s": 45,   # sans reponse : le prompt continue
    "clipboard": True,        # copie le prompt stoppe dans le presse-papiers
    "quota_lock_pct": 97,     # quota Fable hebdo >= : plus de Fable jusqu'au reset
    "extra_fable": [],        # regex perso, +2 chacune
    "extra_trivial": [],      # regex perso, -2 chacune
}

# (points, libelle, regex) — appliquees sur le texte normalise (minuscules, sans accents)
FABLE_SIGNALS = [
    (3, "architecture / conception",
     r"\b(architectur\w*|concevoir|concois|conception|system design|design (?:doc|pattern|system)"
     r"|refonte|re-?architect\w*|from scratch|de zero|modele de donnees|data model|schema de (?:la )?base)\b"),
    (3, "bug coriace",
     r"\b(race conditions?|deadlocks?|fuites? memoire|memory leaks?|heisenbug|intermittent\w*"
     r"|aleatoire(?:ment)?|segfault|corruption|non reproductible|flaky)\b"),
    (3, "déjà essayé sans succès",
     r"(toujours pas|encore (?:le|ce|la|cette) (?:meme )?(?:bug|probleme|erreur)|still (?:not|doesn'?t|fails?|broken)"
     r"|j'?ai (?:deja )?(?:tout )?essaye|deja essaye|tried everything|rien ne marche"
     r"|(?:je )?compren(?:ds|d) pas pourquoi|incomprehensible|ca fait \d+ fois|tourne en rond)"),
    (3, "enjeu élevé",
     r"\b(prod|production|mise en prod|go-?live|critique|critical|securite|security|vulnerab\w*|faille\w*"
     r"|paiements?|payments?|facturation|billing|stripe|donnees (?:clients?|perso\w*|sensibles)|rgpd|gdpr"
     r"|legal|juridique|contrats?|irreversible|deadline|clients? (?:final|important))\b"),
    (2, "tâche importante",
     r"\b(important\w*|crucial\w*|vital\w*|prioritaire|pas le droit a l'?erreur|high stakes|ne (?:te )?(?:plante|rate) pas)\b"),
    (2, "difficulté annoncée",
     r"\b(balese|costaud|complexe|complique\w*|difficile|galere|casse-?tete|epineu\w+|tricky|hard|complex"
     r"|challenging|subtil\w*|chaud)\b"),
    (2, "raisonnement profond",
     r"\b(reflechis (?:bien|a fond)|think (?:hard|deeply)|analyse (?:approfondie|en profondeur|complete)"
     r"|deep dive|pour et le contre|trade-?offs?|compromis|strategi\w+|strategy|audit\w*|root cause"
     r"|cause racine|preuve|prove|demontre)\b"),
    (2, "gros chantier",
     r"\b(refactor\w* (?:global|complet|tout|entier)\w*|migration|migrer|migre|reecri\w* (?:tout|entier|complet)\w*"
     r"|rewrite|tout(?:e)? l'?app\w*|tout le (?:projet|code|repo|systeme|site|backend|frontend|module)"
     r"|whole (?:codebase|project|app)|end[- ]to[- ]end|de a a z|nouveau projet|new project|mvp|pipeline complet)\b"),
    (2, "algo / maths / perf",
     r"\b(algorithm\w*|complexite|optimis\w* (?:les |la |des )?perf\w*|concurrence|concurrency"
     r"|multi-?thread\w*|distribue\w*|cryptograph\w*|mathemati\w*|statisti\w*|modelis\w*)\b"),
    (2, "plan / spec",
     r"\b(plan (?:d'?action|detaille|complet|d'?implementation)|roadmap|specifications?|cahier des charges|prd)\b"),
    (1, "décision structurante",
     r"\b(council this|run the council|war room|pressure-?test|stress-?test|debate this"
     r"|quelle (?:stack|archi\w*|approche)|choix (?:techno\w*|d'?archi\w*)|dois-?je|should (?:i|we))\b"),
]

# comptees seulement sur un prompt court (< 300 car.) : dans un long prompt ces mots sont anecdotiques
OPUS_SIGNALS = [
    (-3, "opération mécanique",
     r"\b(renomm\w*|rename|typo|faute de frappe|orthographe|reformat\w*|formate\w*|indent\w*|lint\w*|prettier"
     r"|bump|changelog|commit\w*|push|pull|merge|rebase|git (?:status|log|diff|add)|install\w*"
     r"|npm (?:i|install|run)|pip install"
     r"|supprime (?:le|la|ce|cette|les) (?:fichier|ligne|commentaire|log)s?)\b"),
    (-2, "petite retouche",
     r"\b(couleur|color|padding|margin|marge|font|police|wording|libelle|label|titre|traduis|translate"
     r"|commentaires?|docstrings?|readme|emoji|icone|centre|aligne)\b"),
    (-2, "question rapide",
     r"^\W*(c'?est quoi|qu'?est-?ce que|what(?:'?s| is)|how do i|comment (?:on )?(?:fait|faire)|ou est"
     r"|where is|quel(?:le)? est|which|rappelle-?moi|remind me|donne-?moi la commande|quelle commande)\b"),
    (-1, "demande d'explication",
     r"^\W*(explique[sz]?(?:-moi)?|explain|resume[sz]?(?:-moi)?|summari[sz]e|decri[st]?(?:-moi)?|montre-moi)\b"),
    (-2, "annoncé comme simple",
     r"\b(vite fait|rapidement|rapide|quick(?:ly)?|juste|just|simple(?:ment)?|petite?|mini|broutille|tout con|trivial)\b"),
]

FENCE = re.compile(r"```.*?```", re.S)
NEGATED = re.compile(
    r"\b(?:pas|peu|aucun\w*|sans)\s+(?:\w+\s+)?(?:important\w*|grave|urgent\w*|critique|complique\w*|difficile|complexe)"
    r"|\brien d'(?:important|grave|urgent|complique)\w*")
CONTINUATION = re.compile(
    r"^\W*(ok(?:ay)?|oui|ouais|yes|yep|non|no|nope|go|vas-?y|allez|continue[sz]?|continu|next|suite|la suite"
    r"|parfait|super|merci|top|nickel|genial|c'?est bon|fais[- ]le|do it|valide|je valide|d'?accord|dacc?"
    r"|carrement|exact(?:ement)?|[a-d1-9])\b[\s\w',.!?-]{0,25}$")
LOGS = re.compile(r"traceback \(most recent|^\s+at \S+ \(|\bexception\b|\berror\b[^\n]*:\d+", re.M)
FILES = re.compile(r"[\w./\\-]+\.(?:py|js|ts|tsx|jsx|json|md|css|html|sql|ya?ml|toml|go|rs|java|cs|php|rb|sh|ps1)\b")
# Messages que l'utilisateur n'a pas tapes (fin de tache de fond, message d'un autre agent) :
# le 24/09, 65 des 94 verdicts Fable de la semaine en venaient.
MACHINE = re.compile(r"\s*<(?:task-notification|agent-message)\b")
# Ce que l'IDE colle devant le prompt (selection, fichier ouvert) : du contexte, pas la demande.
IDE_CONTEXT = re.compile(r"<(ide_selection|ide_opened_file)>.*?</\1>", re.S)
SET_MODEL = re.compile(r'"content":"<local-command-stdout>Set model to [`\'\\"]*([\w.\[\]-]+)')
ASSISTANT_MODEL = re.compile(r'"model":"(claude[^"]+)"')
LINE_TS = re.compile(r'"timestamp":"([^"]+)"')


def load_config():
    cfg = dict(DEFAULT_CONFIG)
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg.update(json.load(f))
    except (OSError, ValueError):
        pass
    return cfg


def normalize(text):
    t = unicodedata.normalize("NFD", text.lower().replace("\u2019", "'"))
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")
    return re.sub(r"[ \t]+", " ", t)


def _hits(rx, text):
    return len({m.group(0) for m in re.finditer(rx, text)})


def classify(prompt, cfg, fable_min=None):
    """-> {verdict: fable|standard|trivial|neutral|bypass, score, reasons}"""
    fable_min = cfg["fable_min"] if fable_min is None else fable_min
    if MACHINE.match(prompt):
        return {"verdict": "bypass", "score": 0, "reasons": ["message automatique"]}
    raw = IDE_CONTEXT.sub(" ", prompt).strip()
    if raw.startswith("="):
        return {"verdict": "bypass", "score": 0, "reasons": ["prefixe ="]}
    if raw.startswith("/"):
        return {"verdict": "neutral", "score": 0, "reasons": ["commande slash"]}
    text = normalize(raw)
    if "#fable" in text or "ultrathink" in text:
        return {"verdict": "fable", "score": 99, "reasons": ["demandé par toi (#fable / ultrathink)"]}
    if "#opus" in text:
        return {"verdict": "standard", "score": 0, "reasons": ["demandé par toi (#opus)"]}
    prose = NEGATED.sub(" ", FENCE.sub(" ", text))
    n = len(prose.strip())
    if n <= 60 and CONTINUATION.match(prose.strip()):
        return {"verdict": "neutral", "score": 0, "reasons": ["suite de conversation"]}

    score, reasons = 0, []
    for pts, label, rx in FABLE_SIGNALS:
        h = _hits(rx, prose)
        if h:
            score += pts + min(h - 1, 2)
            reasons.append(label)
    for rx in cfg.get("extra_fable") or []:
        if re.search(rx, prose):
            score += 2
            reasons.append("perso: " + rx)
    if n >= 1500:
        score, reasons = score + 3, reasons + ["prompt très long"]
    elif n >= 700:
        score, reasons = score + 2, reasons + ["prompt long"]
    elif n >= 350:
        score, reasons = score + 1, reasons + ["prompt détaillé"]
    if len(re.findall(r"(?m)^\s*(?:[-*\u2022]|\d+[.)])\s+\S", text)) >= 4:
        score, reasons = score + 2, reasons + ["liste d'exigences"]
    if FENCE.search(text) or LOGS.search(text):
        score, reasons = score + 1, reasons + ["code / logs collés"]
    if len(set(FILES.findall(text))) >= 4:
        score, reasons = score + 1, reasons + ["multi-fichiers"]

    hard = score > 0
    if n < 300:
        for pts, label, rx in OPUS_SIGNALS:
            h = _hits(rx, prose)
            if h:
                score += pts - min(h - 1, 1)
                reasons.append(label)
        for rx in cfg.get("extra_trivial") or []:
            if re.search(rx, prose):
                score -= 2
                reasons.append("perso: " + rx)
    if not hard and n <= 120:
        score -= 2
        reasons.append("prompt court")
    if n <= 30 and not hard and len(reasons) <= 1:
        return {"verdict": "neutral", "score": score, "reasons": ["trop court pour juger"]}

    if score >= fable_min:
        verdict = "fable"
    elif score <= cfg["trivial_max"]:
        verdict = "trivial"
    else:
        verdict = "standard"
    return {"verdict": verdict, "score": score, "reasons": reasons}


def transcript_model(transcript_path):
    """Dernier modele visible dans le transcript (derniere reponse assistant ou dernier /model)
    -> (modele, timestamp de la ligne). (None, 0) si la session n'a encore aucune reponse."""
    try:
        size = os.path.getsize(transcript_path)
    except OSError:
        return None, 0.0
    for span in (256 * 1024, 4 * 1024 * 1024):
        try:
            with open(transcript_path, "rb") as f:
                f.seek(max(0, size - span))
                lines = f.read().decode("utf-8", "replace").splitlines()
        except OSError:
            return None, 0.0
        for line in reversed(lines):
            if '"isSidechain":true' in line:
                continue
            m = SET_MODEL.search(line)
            if not (m and '"type":"user"' in line):
                m = ASSISTANT_MODEL.search(line) if '"type":"assistant"' in line else None
            if m:
                ts = LINE_TS.search(line)
                return m.group(1), iso_ts(ts.group(1)) if ts else 0.0
        if span >= size:
            break
    return None, 0.0


def session_model(transcript_path):
    return transcript_model(transcript_path)[0]


def iso_ts(text):
    from datetime import datetime
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return 0.0


def settings_model_since():
    """(modele de settings.json, moment ou cette valeur est apparue). `/model` l'ecrit tout de
    suite, alors que le transcript n'enregistre le /model qu'avec le prompt suivant."""
    model = read_settings().get("model")
    try:
        mtime = os.path.getmtime(SETTINGS_PATH)
    except OSError:
        return model, 0.0
    try:
        with open(SETTINGS_SEEN_PATH, "r", encoding="utf-8") as f:
            seen = json.load(f)
    except (OSError, ValueError):
        seen = {}
    if seen.get("model") != model:
        # la valeur a change depuis le dernier prompt : elle date au plus tard de la derniere ecriture
        seen = {"model": model, "since": mtime}
        try:
            os.makedirs(DATA_DIR, exist_ok=True)
            with open(SETTINGS_SEEN_PATH, "w", encoding="utf-8") as f:
                json.dump(seen, f)
        except OSError:
            pass
    return model, seen.get("since", 0.0)


def current_model(transcript_path):
    """Modele de la session -> (modele, premier_prompt). Le transcript est ecrit en differe : un
    /model tape juste avant ce prompt n'y est pas encore. Un changement de modele dans settings.json
    plus recent que la derniere trace du transcript l'emporte donc."""
    seen, seen_ts = transcript_model(transcript_path)
    s_model, s_since = settings_model_since()
    if seen is None:
        return s_model or "", True
    if s_model and s_since > seen_ts and family(s_model) != family(seen):
        return s_model, False
    return seen, False


def delegated_since(transcript_path, offset):
    """True si la session a lance un sous-agent fable-* depuis `offset` (taille du transcript
    au prompt precedent), False sinon, None si illisible."""
    try:
        with open(transcript_path, "rb") as f:
            f.seek(offset)
            tail = f.read().decode("utf-8", "replace")
    except (OSError, ValueError):
        return None
    return bool(re.search(r'"subagent_type":\s*"fable-(?:worker|deep)"', tail))


def family(model):
    return "fable" if "fable" in (model or "").lower() else "light"


def read_settings():
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def default_model():
    return read_settings().get("model")


def fable_quota(db_path=PACE_DB, max_age_s=24 * 3600):
    """(% du quota hebdo Fable, timestamp du reset) lus dans le dernier snapshot API de
    claude-pace. (None, None) si inconnu."""
    try:
        conn = sqlite3.connect("file:" + db_path.replace(os.sep, "/") + "?mode=ro", uri=True, timeout=1)
        row = conn.execute(
            "SELECT ts, raw_json FROM snapshots WHERE model='api' ORDER BY ts DESC LIMIT 1").fetchone()
        conn.close()
        if not row or time.time() - row[0] > max_age_s:
            return None, None
        for lim in json.loads(row[1]).get("limits") or []:
            name = (((lim.get("scope") or {}).get("model") or {}).get("display_name") or "")
            if lim.get("kind") == "weekly_scoped" and "fable" in name.lower():
                reset = None
                try:
                    from datetime import datetime
                    reset = datetime.fromisoformat(lim["resets_at"]).timestamp()
                except (KeyError, TypeError, ValueError):
                    pass
                return float(lim.get("percent")), reset
    except Exception:
        pass
    return None, None


def fable_quota_pct(db_path=PACE_DB):
    return fable_quota(db_path)[0]


def pace_shift(pct, reset, now, cfg, week_s=7 * 86400):
    """Decalage des seuils selon le rythme de conso Fable -> (decalage, % attendu a cette heure).
    En retard sur le rythme qui atteint `pace_target_pct` au reset : seuils plus bas (plus de
    Fable). En avance : seuils plus hauts."""
    if pct is None or reset is None:
        return 0, None
    elapsed = min(max(1 - (reset - now) / week_s, 0.0), 1.0)
    expected = cfg["pace_target_pct"] * elapsed
    gap = pct - expected
    for limit, shift in ((-20, -2), (-8, -1), (8, 0), (20, 1), (35, 2)):
        if gap < limit:
            return shift, expected
    return 3, expected


def write_digest(transcript, session_id, prompt, max_chars):
    """Historique lisible de la conversation (prompts + reponses texte, sans sorties d'outils)
    pour le sous-agent Fable, qui ne voit pas la conversation. -> chemin du fichier, ou None."""
    try:
        size = os.path.getsize(transcript)
        with open(transcript, "rb") as f:
            f.seek(max(0, size - 16 * 1024 * 1024))
            lines = f.read().decode("utf-8", "replace").splitlines()
    except OSError:
        lines = []
    parts = []
    for line in lines:
        if '"isSidechain":true' in line or ('"type":"user"' not in line and '"type":"assistant"' not in line):
            continue
        try:
            r = json.loads(line)
        except ValueError:
            continue
        content = (r.get("message") or {}).get("content")
        if isinstance(content, str):
            texts = [content]
        elif isinstance(content, list):
            texts = [b.get("text", "") for b in content if isinstance(b, dict) and b.get("type") == "text"]
        else:
            continue
        text = "\n".join(t for t in texts if t.strip()).strip()
        if not text or text.startswith(("<local-command", "<command-", "Base directory for this skill",
                                         "<system-reminder>", "<task-notification>")):
            continue
        who = "UTILISATEUR" if r.get("type") == "user" else "CLAUDE"
        parts.append("### " + who + "\n" + text + "\n")
    parts.append("### UTILISATEUR (demande en cours)\n" + prompt.strip() + "\n")
    body = "\n".join(parts)
    if len(body) > max_chars:
        body = "[... début de la conversation coupé ...]\n\n" + body[-max_chars:]
    path = os.path.join(DATA_DIR, "context", session_id + ".md")
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write("# Historique de la conversation (sans les sorties d'outils)\n\n"
                    "Transcript complet, si un détail manque : " + transcript + "\n\n" + body)
    except OSError:
        return None
    return path


def load_state(session_id):
    try:
        with open(os.path.join(STATE_DIR, session_id + ".json"), "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_state(session_id, state):
    os.makedirs(STATE_DIR, exist_ok=True)
    with open(os.path.join(STATE_DIR, session_id + ".json"), "w", encoding="utf-8") as f:
        json.dump(state, f)
    if int(time.time()) % 50 == 0:  # menage occasionnel des sessions de plus de 7 jours
        for name in os.listdir(STATE_DIR):
            p = os.path.join(STATE_DIR, name)
            if time.time() - os.path.getmtime(p) > 7 * 86400:
                os.remove(p)


def log(entry):
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


def decide(side, first_prompt, result, state, cfg, quota, now):
    """-> 'up' | 'down' | None. Met a jour state (cool, pending, snooze)."""
    verdict = result["verdict"]
    pending = state.pop("pending", None)
    if pending and now - pending["ts"] < cfg["grace_min"] * 60:
        # prompt renvoye apres un stop : il passe, et on ne redemande pas de sitot
        state["snooze_" + pending["dir"]] = now + cfg["snooze_min"] * 60
        state["cool"] = 0
        return None
    if verdict in ("neutral", "bypass"):
        return None
    if side == "fable":
        if verdict == "fable":
            state["cool"] = 0
            return None
        state["cool"] = state.get("cool", 0) + (2 if verdict == "trivial" else 1)
        locked = quota is not None and quota >= cfg["quota_lock_pct"]
        if now < state.get("snooze_down", 0) and not locked:
            return None
        if first_prompt or locked or state["cool"] >= cfg["cooldown"]:
            return "down"
        return None
    if verdict == "fable" and now >= state.get("snooze_up", 0):
        if quota is not None and quota >= cfg["quota_lock_pct"]:
            return None
        return "up"
    return None


# sous-agents de ~/.claude/agents/ -> libelle affiche
WORKERS = {"fable-worker": "Fable 5", "fable-deep": "Fable 5, effort xhigh"}


def route(result, prev, cfg, quota):
    """mode auto, session sous un modele leger -> sous-agent Fable a qui deleguer, ou None."""
    verdict, score = result["verdict"], result["score"]
    if quota is not None and quota >= cfg["quota_lock_pct"]:
        return None
    if verdict == "neutral":
        # "ok vas-y", "continue" apres une delegation : on redelegue au meme
        return prev
    if verdict != "fable":
        return None
    return "fable-deep" if cfg["deep_min"] <= score < 99 else "fable-worker"


def delegate_context(worker, result, digest):
    why = ", ".join(result["reasons"][:3]) or "suite de la tâche précédente"
    history = ("l'historique de la conversation est dans " + digest + " : dis-lui de le lire en premier, "
               "puis ajoute dans le brief ce que tu sais de plus (fichiers ouverts, résultats d'outils utiles). "
               if digest else "il ne voit pas cette conversation : mets dans le brief ce que l'utilisateur a "
               "déjà dit, décidé ou essayé. ")
    return ("[model-regulator] DELEGATE " + worker + " : prompt classé exigeant (" + why + "). Tu tournes sous "
            "Opus pour économiser le quota Fable, et l'utilisateur veut que ce type de demande soit traité par "
            "Fable. Confie le travail de fond (conception, diagnostic, analyse, implémentation délicate) au "
            "sous-agent `" + worker + "` via l'outil Agent (subagent_type: \"" + worker + "\"). Son brief : "
            "objectif, fichiers, contraintes ; " + history + "Ensuite vérifie et intègre son résultat, et "
            "réponds à l'utilisateur. Si ce type d'agent n'existe pas, utilise subagent_type "
            "\"general-purpose\" avec model: \"fable\". Ne traite la demande toi-même que si elle se révèle "
            "vraiment simple une fois lue.")


def message(direction, result, quota, cfg):
    why = ", ".join(result["reasons"][:4]) or "-"
    q = "" if quota is None else "\nQuota Fable hebdo : {:.0f} %.".format(quota)
    if direction == "up":
        head = "Ce prompt mérite Fable 5 (score {} : {}).\nTu es sur un modèle plus léger.".format(result["score"], why)
        cmd = "/model fable"
    else:
        head = "Tes derniers prompts ne méritent pas Fable 5 (celui-ci : {}).\nTu es sur Fable.".format(why)
        cmd = "/model opus"
    return head + q, cmd


def ask_dialog(text, cmd, timeout_s):
    """Boite Oui/Non (Windows ou macOS). -> True (stop et switch) | False (continuer) | None (pas de reponse)."""
    paste = "Cmd+V" if sys.platform == "darwin" else "Ctrl+V"
    body = (text + "\n\nOUI = je stoppe ce prompt (copié dans le presse-papiers) :\n"
            "      tape " + cmd + " puis " + paste + " et Entrée.\nNON = on continue comme ça.")
    try:
        if sys.platform == "win32":
            import ctypes
            flags = 0x4 | 0x20 | 0x1000 | 0x10000  # YESNO | ICONQUESTION | SYSTEMMODAL | SETFOREGROUND
            r = ctypes.windll.user32.MessageBoxTimeoutW(0, body, "Régulateur de modèle", flags, 0, int(timeout_s * 1000))
            return True if r == 6 else False if r == 7 else None
        if sys.platform == "darwin":
            quoted = '"' + body.replace("\\", "\\\\").replace('"', '\\"') + '"'
            script = ('display dialog ' + quoted + ' with title "Régulateur de modèle" buttons {"Non", "Oui"} '
                      'default button "Oui" giving up after ' + str(int(timeout_s)))
            r = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=timeout_s + 10)
            if "gave up:true" in r.stdout or r.returncode != 0:
                return None
            return "button returned:Oui" in r.stdout
    except Exception:
        pass
    return None


def keep_prompt(text, clipboard):
    """Un prompt stoppe est efface par Claude Code : on le garde sur disque et dans le presse-papiers."""
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(LAST_PROMPT_PATH, "w", encoding="utf-8") as f:
            f.write(text)
        if clipboard and sys.platform == "win32":
            subprocess.run(["clip"], input=text.encode("utf-16"), timeout=5, check=False,
                           creationflags=subprocess.CREATE_NO_WINDOW)
        elif clipboard and sys.platform == "darwin":
            subprocess.run(["pbcopy"], input=text.encode("utf-8"), timeout=5, check=False)
    except Exception:
        pass


def emit(out):
    """dict -> sortie JSON du hook ; str -> texte brut, ajoute au contexte de Claude."""
    text = out if isinstance(out, str) else json.dumps(out, ensure_ascii=False)
    sys.stdout.buffer.write(text.encode("utf-8"))


def block(text):
    sys.stderr.buffer.write(("⚖️ " + text + "\n").encode("utf-8"))
    sys.exit(2)


def run_hook():
    data = json.loads(sys.stdin.buffer.read().decode("utf-8", "replace") or "{}")
    prompt = data.get("prompt") or ""
    cfg = load_config()
    if not cfg["enabled"] or not prompt.strip() or MACHINE.match(prompt):
        return   # un message automatique ne doit ni compter, ni consommer la delegation en cours
    now = time.time()
    session_id = data.get("session_id") or "unknown"
    transcript = data.get("transcript_path") or ""
    model, first_prompt = current_model(transcript)
    side = family(model)

    quota, reset = fable_quota()
    shift, _ = pace_shift(quota, reset, now, cfg)
    cfg = dict(cfg, fable_min=max(cfg["fable_min"] + shift, 2), deep_min=cfg["deep_min"] + shift)
    result = classify(prompt, cfg)
    state = load_state(session_id)
    prev = state.pop("delegated", None)
    prev_ok = delegated_since(transcript, prev["offset"]) if prev else None

    action, direction, worker, out = "pass", None, None, None
    if cfg["mode"] == "auto" and side == "light":
        worker = route(result, prev and prev["worker"], cfg, quota)
        if worker:
            action = "delegate"
            try:
                offset = os.path.getsize(transcript)
            except OSError:
                offset = 0
            state["delegated"] = {"worker": worker, "offset": offset}
            digest = write_digest(transcript, session_id, prompt, cfg["context_chars"])
            out = {"systemMessage": "⚖️ Délégation à un sous-agent " + WORKERS[worker] + " ("
                                    + (", ".join(result["reasons"][:3]) or "suite") + ")",
                   "hookSpecificOutput": {"hookEventName": "UserPromptSubmit",
                                          "additionalContext": delegate_context(worker, result, digest)}}
    else:
        direction = decide(side, first_prompt, result, state, cfg, quota, now)
    if direction:
        text, cmd = message(direction, result, quota, cfg)
        ui = cfg["ui"]
        if ui == "warn":
            action = "warn"
            out = {"systemMessage": "⚖️ " + text + " → " + cmd}
            state["snooze_" + direction] = now + cfg["snooze_min"] * 60
        else:
            answer = ask_dialog(text, cmd, cfg["dialog_timeout_s"]) if ui == "dialog" else True
            if answer:
                action = "stop"
                state["pending"] = {"dir": direction, "ts": now}
            else:
                action = "refused" if answer is False else "timeout"
                state["snooze_" + direction] = now + (cfg["snooze_min"] if answer is False else 10) * 60
        state["cool"] = 0
    elif side == "fable" and result["verdict"] == "fable" and cfg["deep_min"] <= result["score"] < 99:
        # deja sous Fable : les prompts extremes recoivent le coup de pouce d'`ultrathink`
        action = "deep"
        out = ("[model-regulator] Prompt classé très exigeant (" + ", ".join(result["reasons"][:4]) + "). "
               "Raisonne en profondeur avant de répondre : explore les alternatives, vérifie tes hypothèses, "
               "anticipe les cas limites.")

    save_state(session_id, state)
    log({"ts": round(now), "session": session_id[:8], "model": model, "verdict": result["verdict"],
         "score": result["score"], "reasons": result["reasons"], "action": action, "dir": direction,
         "worker": worker, "prev_ok": prev_ok, "shift": shift, "chars": len(prompt), "preview": prompt.strip()[:60]})
    if action == "stop":
        keep_prompt(prompt, cfg["clipboard"])
        block(text + "\nPrompt copié dans le presse-papiers → tape " + cmd + " puis "
              + ("Cmd+V" if sys.platform == "darwin" else "Ctrl+V") + " et Entrée."
              "\n(Renvoyer le prompt tel quel sans switcher = rester sur le modèle actuel.)")
    if out:
        emit(out)


def read_log(days=7):
    since = time.time() - days * 86400
    rows = []
    try:
        with open(LOG_PATH, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    e = json.loads(line)
                except ValueError:
                    continue
                if e.get("ts", 0) >= since:
                    rows.append(e)
    except OSError:
        pass
    return rows


def cmd_status():
    cfg = load_config()
    quota, reset = fable_quota()
    shift, expected = pace_shift(quota, reset, time.time(), cfg)
    mode = "auto (délégation Fable), ui={} sous Fable" if cfg["mode"] == "auto" else "ask, ui={}"
    mode = mode.format(cfg["ui"])
    print("model-regulator : {}  |  mode {}".format("ON" if cfg["enabled"] else "OFF", mode))
    print("seuils de base : fable_min={}  deep_min={}  |  seuils actuels : fable {}  deep {}".format(
        cfg["fable_min"], cfg["deep_min"], max(cfg["fable_min"] + shift, 2), cfg["deep_min"] + shift))
    settings = read_settings()
    print("modèle par défaut (settings.json) : {}".format(settings.get("model")))
    for name, ms in (settings.get("modelSettings") or {}).items():
        level = (ms or {}).get("effortLevel")
        costly = "fable" in name.lower() and level in ("xhigh", "max")
        print("effort enregistré {} : {}{}".format(
            name, level, "  <- cher : `high` est le défaut conseillé (/effort high sous Fable)" if costly else ""))
    if quota is None:
        print("quota Fable hebdo : inconnu (claude-pace absent ou snapshot API trop vieux) -> seuils de base")
    elif quota >= cfg["quota_lock_pct"]:
        print("quota Fable hebdo : {:.0f} %  -> VERROUILLÉ jusqu'au reset".format(quota))
    else:
        where = "" if expected is None else "  (rythme visé : {:.0f} % à cette heure pour finir à {} %)".format(
            expected, cfg["pace_target_pct"])
        print("quota Fable hebdo : {:.0f} %{}  -> seuils {:+d}".format(quota, where, shift))
    rows = read_log(1)
    if not rows:
        print("aucune décision aujourd'hui (hook pas installé, ou aucun prompt depuis)")
    for e in rows[-5:]:
        print("  {}  {:<6} {:<8} {:>3}  {:<12} {}".format(
            time.strftime("%H:%M", time.localtime(e["ts"])), family(e["model"]), e["verdict"], e["score"],
            e.get("worker") or e["action"], e["preview"]))


def cmd_stats():
    rows = read_log(7)
    judged = [e for e in rows if e["verdict"] not in ("neutral", "bypass")]
    on_fable = [e for e in judged if family(e["model"]) == "fable"]
    wasted = [e for e in on_fable if e["verdict"] != "fable"]
    print("7 derniers jours : {} prompts, dont {} jugés".format(len(rows), len(judged)))
    print("  session sous Fable : {}  ({} ne le méritaient pas)".format(len(on_fable), len(wasted)))
    print("  session sous Opus/autre : {}".format(len(judged) - len(on_fable)))
    for w in WORKERS:
        n = sum(1 for e in rows if e.get("worker") == w)
        if n:
            print("  délégations {:<13} {}".format(w, n))
    checked = [e["prev_ok"] for e in rows if e.get("prev_ok") is not None]
    if checked:
        print("  délégations réellement faites par Opus : {} / {}".format(sum(checked), len(checked)))
    for a in ("stop", "refused", "timeout", "warn"):
        ups = sum(1 for e in rows if e["action"] == a and e.get("dir") == "up")
        downs = sum(1 for e in rows if e["action"] == a and e.get("dir") == "down")
        if ups or downs:
            print("  {:<9} monter: {}  redescendre: {}".format(a, ups, downs))


def cmd_toggle(enabled):
    cfg = {}
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)
    except (OSError, ValueError):
        pass
    cfg["enabled"] = enabled
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    print("model-regulator :", "ON" if enabled else "OFF")


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "hook"
    if cmd == "hook":
        try:
            run_hook()
        except SystemExit:
            raise
        except Exception:
            pass  # fail-open : le prompt passe
        return
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    if cmd == "test":
        cfg = load_config()
        print(json.dumps(classify(" ".join(sys.argv[2:]), cfg), ensure_ascii=False, indent=2))
    elif cmd == "status":
        cmd_status()
    elif cmd == "stats":
        cmd_stats()
    elif cmd in ("on", "off"):
        cmd_toggle(cmd == "on")
    else:
        print(__doc__)


if __name__ == "__main__":
    main()
