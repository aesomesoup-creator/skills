#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Tests de model-regulator. Tout tourne dans un dossier temporaire : ni ~/.claude,
ni le presse-papiers, ni ~/.claude-pace ne sont touches.

  python test_regulator.py
"""
import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import time
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import regulator as R  # noqa: E402

CFG = dict(R.DEFAULT_CONFIG)
NOW = 1_800_000_000.0

FABLE = [
    "conçois l'architecture complète du backend pour gérer les paiements en production",
    "fix le bug du bouton login qui marche toujours pas, j'ai déjà essayé 3 trucs",
    "refais moi tout le système d'auth, c'est critique pour la prod",
    "lance l'audit de sécurité complet de l'app avant la mise en prod",
    "renomme ça #fable",
    "j'ai une race condition intermittente dans le worker, je comprends pas pourquoi",
]
NOT_FABLE = [
    "renomme la variable foo en bar",
    "commit et push",
    "c'est quoi la différence entre let et const",
    "ajoute un bouton de déconnexion dans la navbar",
    "explique-moi l'architecture de ce repo",
    "change la couleur du titre en bleu, c'est pas important",
    "refais toute l'archi de prod #opus",
]
NEUTRAL = ["ok vas-y", "oui", "continue", "/model-regulator stats", "merci c'est parfait", "et là ?"]


class Classify(unittest.TestCase):
    def test_fable(self):
        for p in FABLE:
            self.assertEqual(R.classify(p, CFG)["verdict"], "fable", p)

    def test_not_fable(self):
        for p in NOT_FABLE:
            self.assertIn(R.classify(p, CFG)["verdict"], ("standard", "trivial"), p)

    def test_neutral(self):
        for p in NEUTRAL:
            self.assertEqual(R.classify(p, CFG)["verdict"], "neutral", p)

    def test_bypass(self):
        self.assertEqual(R.classify("= refonte totale de la prod", CFG)["verdict"], "bypass")

    def test_machine_messages_are_ignored(self):
        long_task = "architecture critique de la prod, bug coriace, refonte complète\n" + "- point\n" * 10
        for p in ("<task-notification>\n<task-id>x</task-id>\n" + long_task + "</task-notification>",
                  '<agent-message from="a1b2"> [Subagent hand-back]\n' + long_task):
            self.assertEqual(R.classify(p, CFG)["verdict"], "bypass", p[:30])

    def test_ide_context_not_scored(self):
        sel = "<ide_selection>" + "const x = compute(a, b);\n" * 80 + "</ide_selection>"
        self.assertIn(R.classify(sel + "renomme cette variable", CFG)["verdict"], ("standard", "trivial"))
        self.assertEqual(R.classify(sel + "j'ai une race condition intermittente dans le worker, "
                                          "je comprends pas pourquoi", CFG)["verdict"], "fable")

    def test_long_spec_is_fable(self):
        spec = "Voici ce que je veux pour le module.\n" + "\n".join(
            "- exigence numéro {} : le comportement attendu est décrit ici en détail".format(i) for i in range(12))
        self.assertEqual(R.classify(spec, CFG)["verdict"], "fable")

    def test_raised_threshold(self):
        p = "fix le bug du bouton login qui marche toujours pas, j'ai déjà essayé 3 trucs"
        self.assertEqual(R.classify(p, CFG, CFG["fable_min"] + 2)["verdict"], "standard")

    def test_trivial_words_ignored_in_long_prompt(self):
        p = "juste " + "blabla " * 60
        self.assertNotIn("annoncé comme simple", R.classify(p, CFG)["reasons"])


def _line(kind, **kw):
    if kind == "assistant":
        return json.dumps({"isSidechain": kw.get("side", False), "type": "assistant",
                           "message": {"model": kw["model"], "role": "assistant"}}, separators=(",", ":"))
    if kind == "setmodel":
        return json.dumps({"isSidechain": False, "type": "user", "message": {
            "role": "user", "content": "<local-command-stdout>Set model to `%s`</local-command-stdout>" % kw["model"]}},
            separators=(",", ":"))
    return json.dumps({"isSidechain": False, "type": "user", "message": {"role": "user", "content": kw["text"]}},
                      separators=(",", ":"))


class SessionModel(unittest.TestCase):
    def _write(self, lines):
        f = tempfile.NamedTemporaryFile("w", suffix=".jsonl", delete=False, encoding="utf-8")
        f.write("\n".join(lines) + "\n")
        f.close()
        self.addCleanup(os.remove, f.name)
        return f.name

    def test_missing_or_empty_is_first_prompt(self):
        self.assertIsNone(R.session_model("Z:/nope.jsonl"))
        self.assertIsNone(R.session_model(self._write([_line("user", text="salut")])))

    def test_last_assistant(self):
        p = self._write([_line("assistant", model="claude-fable-5-1"), _line("assistant", model="claude-opus-5")])
        self.assertEqual(R.session_model(p), "claude-opus-5")

    def test_model_command_wins_when_later(self):
        p = self._write([_line("assistant", model="claude-opus-5"), _line("setmodel", model="claude-fable-5-1[1m]")])
        self.assertEqual(R.session_model(p), "claude-fable-5-1[1m]")

    def test_ignores_sidechain_synthetic_and_quotes(self):
        p = self._write([
            _line("assistant", model="claude-opus-5"),
            _line("assistant", model="claude-fable-5-1", side=True),
            _line("assistant", model="<synthetic>"),
            _line("user", text="dans le log je vois Set model to `claude-fable-5-1`"),
        ])
        self.assertEqual(R.session_model(p), "claude-opus-5")


class CurrentModel(unittest.TestCase):
    """Le /model tape juste avant un prompt n'est ecrit dans le transcript qu'avec ce prompt
    (bug vu le 2026-09-22) : settings.json, ecrit tout de suite, doit l'emporter."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.saved = (R.SETTINGS_PATH, R.SETTINGS_SEEN_PATH, R.DATA_DIR)
        R.DATA_DIR = self.tmp.name
        R.SETTINGS_PATH = os.path.join(self.tmp.name, "settings.json")
        R.SETTINGS_SEEN_PATH = os.path.join(self.tmp.name, "settings_model.json")
        self.addCleanup(lambda: setattr(R, "SETTINGS_PATH", self.saved[0]) or
                        setattr(R, "SETTINGS_SEEN_PATH", self.saved[1]) or setattr(R, "DATA_DIR", self.saved[2]))
        self.transcript = os.path.join(self.tmp.name, "t.jsonl")

    def settings(self, model, mtime):
        with open(R.SETTINGS_PATH, "w") as f:
            json.dump({"model": model}, f)
        os.utime(R.SETTINGS_PATH, (mtime, mtime))

    def answered(self, model, ts):
        stamp = time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime(ts))
        with open(self.transcript, "a") as f:
            f.write(json.dumps({"isSidechain": False, "type": "assistant", "timestamp": stamp,
                                "message": {"model": model}}, separators=(",", ":")) + "\n")

    def test_model_switch_not_yet_in_transcript(self):
        self.answered("claude-fable-5-1", NOW)
        self.settings("claude-opus-5[1m]", NOW + 30)                 # /model opus, 30 s apres
        self.assertEqual(R.current_model(self.transcript), ("claude-opus-5[1m]", False))

    def test_older_settings_do_not_override(self):
        self.settings("claude-opus-5[1m]", NOW)
        self.answered("claude-fable-5-1", NOW + 60)                  # la session a repondu sous Fable apres
        self.assertEqual(R.current_model(self.transcript), ("claude-fable-5-1", False))

    def test_unrelated_settings_write_does_not_override(self):
        self.settings("claude-opus-5[1m]", NOW)
        R.current_model(self.transcript)                             # valeur vue a NOW
        self.answered("claude-fable-5-1", NOW + 60)
        self.settings("claude-opus-5[1m]", NOW + 120)                # autre reglage modifie, modele inchange
        self.assertEqual(R.current_model(self.transcript)[0], "claude-fable-5-1")

    def test_first_prompt_uses_settings(self):
        self.settings("claude-opus-5[1m]", NOW)
        self.assertEqual(R.current_model(self.transcript), ("claude-opus-5[1m]", True))


class Decide(unittest.TestCase):
    def d(self, side, verdict, state, first=False, quota=None, now=NOW):
        return R.decide(side, first, {"verdict": verdict}, state, CFG, quota, now)

    def test_up_on_hard_prompt(self):
        self.assertEqual(self.d("light", "fable", {}), "up")
        self.assertIsNone(self.d("light", "standard", {}))
        self.assertIsNone(self.d("light", "fable", {"snooze_up": NOW + 60}))

    def test_down_needs_a_streak(self):
        s = {}
        self.assertIsNone(self.d("fable", "trivial", s))   # cool = 2
        self.assertIsNone(self.d("fable", "neutral", s))   # inchange
        self.assertIsNone(self.d("fable", "standard", s))  # cool = 3
        self.assertEqual(self.d("fable", "standard", s), "down")

    def test_hard_prompt_resets_streak(self):
        s = {"cool": 3}
        self.assertIsNone(self.d("fable", "fable", s))
        self.assertEqual(s["cool"], 0)

    def test_first_prompt_on_fable_is_immediate(self):
        self.assertEqual(self.d("fable", "standard", {}, first=True), "down")

    def test_resend_after_stop_passes_and_snoozes(self):
        s = {"pending": {"dir": "up", "ts": NOW - 30}}
        self.assertIsNone(self.d("light", "fable", s))
        self.assertGreater(s["snooze_up"], NOW)
        self.assertNotIn("pending", s)

    def test_quota_lock(self):
        self.assertIsNone(self.d("light", "fable", {}, quota=97))
        self.assertEqual(self.d("fable", "standard", {"snooze_down": NOW + 600}, quota=97), "down")


def _make_pace_db(path, percent, age_s=60):
    conn = sqlite3.connect(path)
    conn.execute("CREATE TABLE snapshots(ts REAL, model TEXT, raw_json TEXT)")
    raw = {"limits": [{"kind": "weekly_all", "percent": 44, "scope": None},
                      {"kind": "weekly_scoped", "percent": percent,
                       "scope": {"model": {"id": None, "display_name": "Fable"}}}]}
    conn.execute("INSERT INTO snapshots VALUES(?,?,?)", (time.time() - age_s, "api", json.dumps(raw)))
    conn.commit()
    conn.close()


class Quota(unittest.TestCase):
    def test_reads_fable_bucket(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "pace.db")
            _make_pace_db(db, 84)
            self.assertEqual(R.fable_quota_pct(db), 84.0)

    def test_stale_or_missing(self):
        with tempfile.TemporaryDirectory() as d:
            db = os.path.join(d, "pace.db")
            _make_pace_db(db, 84, age_s=3 * 86400)
            self.assertIsNone(R.fable_quota_pct(db))
            self.assertIsNone(R.fable_quota_pct(os.path.join(d, "absent.db")))


class Route(unittest.TestCase):
    def r(self, verdict, score=0, prev=None, quota=None):
        return R.route({"verdict": verdict, "score": score}, prev, CFG, quota)

    def test_routes(self):
        self.assertEqual(self.r("fable", 5), "fable-worker")
        self.assertEqual(self.r("fable", 9), "fable-deep")
        self.assertEqual(self.r("fable", 99), "fable-worker")      # #fable : pas forcement extreme
        for v in ("standard", "trivial", "bypass"):
            self.assertIsNone(self.r(v, 0))

    def test_continuation_redelegates(self):
        self.assertEqual(self.r("neutral", prev="fable-deep"), "fable-deep")
        self.assertIsNone(self.r("neutral"))

    def test_quota_lock(self):
        self.assertIsNone(self.r("fable", 9, quota=98))
        self.assertIsNone(self.r("neutral", prev="fable-deep", quota=98))


class Pace(unittest.TestCase):
    WEEK = 7 * 86400

    def shift(self, pct, elapsed_frac):
        return R.pace_shift(pct, NOW + (1 - elapsed_frac) * self.WEEK, NOW, CFG)[0]

    def test_on_pace_is_neutral(self):
        self.assertEqual(self.shift(47.5, 0.5), 0)          # 95 % vises, mi-semaine

    def test_behind_lowers_thresholds(self):
        self.assertEqual(self.shift(35, 0.5), -1)
        self.assertEqual(self.shift(10, 0.5), -2)

    def test_ahead_raises_thresholds(self):
        self.assertEqual(self.shift(62, 0.5), 1)
        self.assertEqual(self.shift(88, 0.63), 2)           # la situation du 2026-09-21
        self.assertEqual(self.shift(90, 0.3), 3)

    def test_unknown_is_neutral(self):
        self.assertEqual(R.pace_shift(None, None, NOW, CFG), (0, None))


class Digest(unittest.TestCase):
    def test_keeps_dialogue_drops_tools_and_meta(self):
        with tempfile.TemporaryDirectory() as d:
            t = os.path.join(d, "t.jsonl")
            rows = [
                {"type": "user", "message": {"content": "on refait le module de paiement"}},
                {"type": "assistant", "message": {"content": [{"type": "thinking", "thinking": "secret"},
                                                              {"type": "text", "text": "Voici le plan en 3 étapes"},
                                                              {"type": "tool_use", "name": "Bash", "input": {}}]}},
                {"type": "user", "message": {"content": [{"type": "tool_result", "content": "SORTIE OUTIL"}]}},
                {"type": "user", "message": {"content": "<local-command-stdout>Set model to x</local-command-stdout>"}},
                {"type": "assistant", "isSidechain": True, "message": {"content": [{"type": "text", "text": "SOUS-AGENT"}]}},
            ]
            with open(t, "w", encoding="utf-8") as f:
                f.write("\n".join(json.dumps(r, separators=(",", ":")) for r in rows))
            old = R.DATA_DIR
            R.DATA_DIR = d
            try:
                body = open(R.write_digest(t, "s1", "et la migration ?", 10000), encoding="utf-8").read()
                short = open(R.write_digest(t, "s2", "et la migration ?", 60), encoding="utf-8").read()
            finally:
                R.DATA_DIR = old
            self.assertIn("on refait le module de paiement", body)
            self.assertIn("Voici le plan en 3 étapes", body)
            self.assertIn("et la migration ?", body)
            for absent in ("secret", "SORTIE OUTIL", "Set model", "SOUS-AGENT"):
                self.assertNotIn(absent, body)
            self.assertIn("coupé", short)
            self.assertIn("et la migration ?", short)


class HookBase(unittest.TestCase):
    """Lance le vrai script avec un HOME temporaire (sans presse-papiers ni pace.db)."""
    CONFIG = {}

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        home = self.tmp.name
        os.makedirs(os.path.join(home, ".claude-regulator"))
        os.makedirs(os.path.join(home, ".claude"))
        with open(os.path.join(home, ".claude-regulator", "config.json"), "w") as f:
            json.dump(dict(self.CONFIG, clipboard=False), f)
        self.env = dict(os.environ, USERPROFILE=home, HOME=home)
        self.home = home
        self.transcript = os.path.join(home, "t.jsonl")

    def settings(self, model):
        with open(os.path.join(self.home, ".claude", "settings.json"), "w") as f:
            json.dump({"model": model}, f)

    def turn(self, kind, model):
        with open(self.transcript, "a", encoding="utf-8") as f:
            f.write(_line(kind, model=model) + "\n")

    def hook(self, prompt, transcript=None):
        payload = json.dumps({"session_id": "s1", "transcript_path": transcript or "Z:/nope.jsonl", "prompt": prompt})
        return subprocess.run([sys.executable, os.path.join(HERE, "regulator.py"), "hook"],
                              input=payload.encode("utf-8"), capture_output=True, env=self.env, timeout=30)

    def log(self):
        with open(os.path.join(self.home, ".claude-regulator", "log.jsonl"), encoding="utf-8") as f:
            return [json.loads(l) for l in f]


HARD = "conçois l'architecture complète du backend pour gérer les paiements en production"
MEDIUM_HARD = "fix le bug du bouton login qui marche toujours pas, j'ai déjà essayé 3 trucs"


class HookAuto(HookBase):
    def ctx(self, r):
        self.assertEqual(r.returncode, 0)
        if not r.stdout:
            return None
        return json.loads(r.stdout.decode("utf-8"))["hookSpecificOutput"]["additionalContext"]

    def spawn(self, worker):
        with open(self.transcript, "a", encoding="utf-8") as f:
            f.write(json.dumps({"type": "assistant", "message": {"model": "claude-opus-5", "content": [
                {"type": "tool_use", "name": "Agent", "input": {"subagent_type": worker}}]}},
                separators=(",", ":")) + "\n")

    def test_delegate_then_continuation_then_normal(self):
        self.settings("claude-opus-5[1m]")
        self.turn("assistant", "claude-opus-5")
        ctx = self.ctx(self.hook(MEDIUM_HARD, self.transcript))
        self.assertIn("DELEGATE fable-worker", ctx)
        digest = os.path.join(self.home, ".claude-regulator", "context", "s1.md")
        self.assertIn(digest, ctx)
        self.assertIn("j'ai déjà essayé 3 trucs", open(digest, encoding="utf-8").read())
        self.spawn("fable-worker")                                 # Opus a bien delegue
        self.assertIn("DELEGATE fable-worker", self.ctx(self.hook("ok vas-y", self.transcript)))
        self.turn("assistant", "claude-opus-5")                    # pas de delegation cette fois
        self.assertIsNone(self.ctx(self.hook("ajoute un bouton de déconnexion dans la navbar", self.transcript)))
        self.assertEqual([e["prev_ok"] for e in self.log()], [None, True, False])

    def test_extreme_prompt_goes_deep(self):
        self.settings("claude-opus-5[1m]")
        self.assertIn("DELEGATE fable-deep", self.ctx(self.hook(HARD)))

    def test_on_fable_falls_back_to_ask(self):
        self.settings("claude-fable-5-1[1m]")
        with open(os.path.join(self.home, ".claude-regulator", "config.json"), "w") as f:
            json.dump({"ui": "block", "clipboard": False}, f)
        r = self.hook("renomme la variable foo en bar")
        self.assertEqual(r.returncode, 2)
        self.assertIn("/model opus", r.stderr.decode("utf-8"))

    def test_matching_model_is_silent(self):
        self.settings("claude-opus-5[1m]")
        r = self.hook("renomme la variable foo en bar")
        self.assertEqual((r.returncode, r.stdout, r.stderr), (0, b"", b""))


class HookAsk(HookBase):
    CONFIG = {"mode": "ask", "ui": "block"}

    def test_hard_prompt_on_opus_is_stopped_then_resend_passes(self):
        self.settings("claude-opus-5[1m]")
        p = "conçois l'architecture complète du backend pour gérer les paiements en production"
        r = self.hook(p)
        self.assertEqual(r.returncode, 2)
        self.assertIn("/model fable", r.stderr.decode("utf-8"))
        with open(os.path.join(self.home, ".claude-regulator", "last_blocked_prompt.txt"), encoding="utf-8") as f:
            self.assertEqual(f.read(), p)
        self.assertEqual(self.hook(p).returncode, 0)

    def test_trivial_first_prompt_on_fable_is_stopped(self):
        self.settings("claude-fable-5-1[1m]")
        r = self.hook("renomme la variable foo en bar")
        self.assertEqual(r.returncode, 2)
        self.assertIn("/model opus", r.stderr.decode("utf-8"))

    def test_matching_model_is_silent(self):
        self.settings("claude-opus-5[1m]")
        r = self.hook("renomme la variable foo en bar")
        self.assertEqual((r.returncode, r.stdout, r.stderr), (0, b"", b""))

    def test_extreme_prompt_on_fable_gets_deep_reasoning_context(self):
        self.settings("claude-fable-5-1[1m]")
        r = self.hook("conçois l'architecture complète du backend pour gérer les paiements en production")
        self.assertEqual(r.returncode, 0)
        self.assertIn("Raisonne en profondeur", r.stdout.decode("utf-8"))

    def test_hard_but_not_extreme_on_fable_is_silent(self):
        self.settings("claude-fable-5-1[1m]")
        r = self.hook("fix le bug du bouton login qui marche toujours pas, j'ai déjà essayé 3 trucs")
        self.assertEqual((r.returncode, r.stdout), (0, b""))

    def test_garbage_input_fails_open(self):
        self.settings("claude-opus-5[1m]")
        r = subprocess.run([sys.executable, os.path.join(HERE, "regulator.py"), "hook"],
                           input=b"pas du json", capture_output=True, env=self.env, timeout=30)
        self.assertEqual((r.returncode, r.stdout), (0, b""))

    def test_off(self):
        self.settings("claude-fable-5-1")
        with open(os.path.join(self.home, ".claude-regulator", "config.json"), "w") as f:
            json.dump({"enabled": False}, f)
        self.assertEqual(self.hook("renomme la variable foo en bar").returncode, 0)


if __name__ == "__main__":
    unittest.main()
