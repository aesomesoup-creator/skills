#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Installe model-regulator dans ~/.claude (macOS, Windows, Linux).

  python3 install.py            installe ou met a jour
  python3 install.py --dry-run  montre ce qui changerait, sans rien ecrire

- copie skills/ et agents/ dans ~/.claude/
- ajoute le hook UserPromptSubmit dans ~/.claude/settings.json, avec l'interpreteur
  Python qui lance ce script (sauvegarde settings.json.bak-model-regulator avant)
- met le modele par defaut sur opus[1m] et l'effort Fable enregistre sur high
Relancer le script est sans danger : rien n'est ajoute en double.
"""
import json
import os
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
CLAUDE = os.path.join(os.path.expanduser("~"), ".claude")
SETTINGS = os.path.join(CLAUDE, "settings.json")
PARTS = [("skills", "model-regulator"), ("skills", "fable-boost"),
         ("agents", "fable-worker.md"), ("agents", "fable-deep.md")]


def hook_command():
    script = os.path.join(CLAUDE, "skills", "model-regulator", "regulator.py")
    return '"{}" "{}" hook'.format(sys.executable.replace("\\", "/"), script.replace("\\", "/"))


def copy_parts(dry):
    for folder, name in PARTS:
        src = os.path.join(HERE, folder, name)
        dst = os.path.join(CLAUDE, folder, name)
        print("  copie", os.path.join(folder, name), "->", dst)
        if dry:
            continue
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        if os.path.isdir(src):
            shutil.copytree(src, dst, dirs_exist_ok=True,
                            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        else:
            shutil.copy2(src, dst)


def patch_settings(dry):
    try:
        with open(SETTINGS, "r", encoding="utf-8") as f:
            settings = json.load(f)
    except FileNotFoundError:
        settings = {}
    before = json.dumps(settings, sort_keys=True)

    ups = settings.setdefault("hooks", {}).setdefault("UserPromptSubmit", [])
    cmd = hook_command()
    mine = [h for e in ups for h in e.get("hooks", []) if "model-regulator" in h.get("command", "")]
    if mine:
        for h in mine:
            h["command"], h["timeout"] = cmd, 90
    else:
        ups.append({"hooks": [{"type": "command", "command": cmd, "timeout": 90}]})
    settings["model"] = "opus[1m]"
    settings.setdefault("modelSettings", {}).setdefault("claude-fable-5-1", {})["effortLevel"] = "high"

    if json.dumps(settings, sort_keys=True) == before:
        print("  settings.json : déjà à jour")
        return
    print("  settings.json : hook ->", cmd)
    print("                  model -> opus[1m], effort Fable -> high")
    if dry:
        return
    if os.path.exists(SETTINGS):
        shutil.copy2(SETTINGS, SETTINGS + ".bak-model-regulator")
    os.makedirs(CLAUDE, exist_ok=True)
    tmp = SETTINGS + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        json.dump(settings, f, indent=2, ensure_ascii=False)
        f.write("\n")
    os.replace(tmp, SETTINGS)


def main():
    dry = "--dry-run" in sys.argv
    print("model-regulator ->", CLAUDE, "(simulation)" if dry else "")
    copy_parts(dry)
    patch_settings(dry)
    if not dry:
        print("\nFait. Ouvre une nouvelle session Claude Code (les agents se chargent au démarrage),")
        print("envoie un prompt, puis tape /model-regulator.")


if __name__ == "__main__":
    main()
