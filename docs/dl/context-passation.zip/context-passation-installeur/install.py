"""Installe le skill context-passation pour Claude Code.   (macOS / Linux : python3)

    python install.py                         # demande où ranger les passations
    python install.py --dossier <chemin>      # ex. ~/Documents/MonVault/passations
    python install.py --sans-git              # ne jamais commit/push, même dans un dépôt git
    python install.py --desinstaller

Copie context-passation/ dans ~/.claude/skills/ et ajoute ses hooks à ~/.claude/settings.json
(sauvegardé avant). Règle aussi la compaction automatique de Claude Code à 300k tokens
(autoCompactWindow), sauf si une valeur est déjà choisie : la fiche est écrite juste avant.
Relancer l'installation garde le dossier choisi la première fois.
"""
import json
import os
import shutil
import sys

SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'context-passation')
CLAUDE = os.path.join(os.path.expanduser('~'), '.claude')
DEST = os.path.join(CLAUDE, 'skills', 'context-passation')
SETTINGS = os.path.join(CLAUDE, 'settings.json')
DEFAULT = os.path.join('~', '.claude', 'passations')
MARK = 'context-passation/hooks/'
AUTO_COMPACT = 300_000  # fenêtre de compaction posée si aucune n'est réglée


def posix(p):
    return p.replace('\\', '/')


def python_exe():
    d, b = os.path.split(sys.executable)
    if b.lower() == 'pythonw.exe':  # pythonw n'a pas de stdout, or les hooks répondent sur stdout
        return posix(os.path.join(d, 'python.exe'))
    return posix(sys.executable)


def read_settings():
    if not os.path.exists(SETTINGS):
        return {}
    with open(SETTINGS, encoding='utf-8') as fh:
        return json.load(fh)


def write_settings(settings):
    if os.path.exists(SETTINGS):
        shutil.copy2(SETTINGS, SETTINGS + '.bak-context-passation')
    text = json.dumps(settings, indent=2, ensure_ascii=False) + '\n'
    json.loads(text)
    os.makedirs(CLAUDE, exist_ok=True)
    with open(SETTINGS, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write(text)


def strip_hooks(settings):
    hooks = settings.get('hooks', {})
    for event in list(hooks):
        hooks[event] = [e for e in hooks[event]
                        if not any(MARK in h.get('command', '') for h in e.get('hooks', []))]
        if not hooks[event]:
            del hooks[event]
    return hooks


def installed_config():
    try:
        with open(os.path.join(DEST, 'config.json'), encoding='utf-8') as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def choose_config(args):
    config = installed_config()
    if '--dossier' in args:
        config['dossier'] = args[args.index('--dossier') + 1]
    elif 'dossier' not in config:
        answer = ''
        if sys.stdin.isatty():
            print('Où ranger les passations ? Un dossier de ton vault Obsidian est idéal,')
            print("par exemple ~/Documents/MonVault/passations. S'il est dans un dépôt git,")
            print('les passations y sont commitées et poussées (reprise possible sur une autre machine).')
            try:
                answer = input(f'Dossier [{DEFAULT}] : ').strip()
            except EOFError:  # sous Windows, NUL se fait passer pour un terminal
                print()
        config['dossier'] = answer or DEFAULT
    config['dossier'] = posix(os.path.abspath(os.path.expanduser(config['dossier'])))
    if '--sans-git' in args:
        config['git'] = False
    return config


def install(args):
    if os.path.islink(DEST):  # rmtree ne suit pas un lien : on écraserait à moitié une autre installation
        sys.exit(f"{posix(DEST)} est un lien vers une autre installation : mets celle-là à jour. Rien n'est modifié.")
    py = python_exe()
    config = choose_config(args)
    settings = read_settings()
    if 'autoCompactWindow' not in settings:
        settings['autoCompactWindow'] = AUTO_COMPACT
        config['compaction_posee'] = True  # la désinstallation ne retire que ce qu'elle a posé
    shutil.rmtree(DEST, ignore_errors=True)
    shutil.copytree(SRC, DEST, ignore=shutil.ignore_patterns('__pycache__', 'config.json'))
    with open(os.path.join(DEST, 'config.json'), 'w', encoding='utf-8') as fh:
        json.dump(config, fh, indent=2, ensure_ascii=False)

    hooks = strip_hooks(settings)
    settings['hooks'] = hooks
    cmd = lambda script: f'"{py}" "{posix(DEST)}/hooks/{script}"'  # noqa: E731
    hooks.setdefault('SessionStart', []).append(
        {'matcher': 'startup|clear|compact', 'hooks': [{'type': 'command', 'command': cmd('session_start.py'), 'timeout': 30}]})
    for event in ('UserPromptSubmit', 'PostToolUse'):
        hooks.setdefault(event, []).append(
            {'hooks': [{'type': 'command', 'command': cmd('context_watch.py'), 'timeout': 10}]})
    write_settings(settings)

    print(f'Skill installé dans {posix(DEST)}')
    print(f"Passations rangées dans {config['dossier']}" + (' (sans git)' if config.get('git') is False else ''))
    print(f'Hooks SessionStart, UserPromptSubmit et PostToolUse ajoutés à {posix(SETTINGS)} (sauvegarde : settings.json.bak-context-passation)')
    print(f"Compaction automatique à {settings['autoCompactWindow']} tokens (autoCompactWindow)"
          + ('' if settings['autoCompactWindow'] == AUTO_COMPACT else ' : valeur déjà choisie, gardée'))
    print('Actif dans les prochaines sessions Claude Code.')


def uninstall():
    posee = installed_config().get('compaction_posee') is True
    settings = read_settings()
    retire = posee and settings.get('autoCompactWindow') == AUTO_COMPACT
    if settings.get('hooks') or retire:
        strip_hooks(settings)
        if retire:
            del settings['autoCompactWindow']
        write_settings(settings)
    shutil.rmtree(DEST, ignore_errors=True)
    shutil.rmtree(os.path.join(CLAUDE, 'context-passation'), ignore_errors=True)
    print('Skill et hooks retirés. Les passations déjà écrites restent dans leur dossier.')


if __name__ == '__main__':
    if '--desinstaller' in sys.argv:
        uninstall()
    else:
        install(sys.argv[1:])
