"""Passations de contexte (skill context-passation).

Une passation en attente par projet : <dossier>/<projet>-AAAA-MM-JJ-HHMM.md. Quand elle est
reprise, ou remplacée par une nouvelle, elle passe en tête de <dossier>/historique/<projet>.md.
Le dossier est choisi à l'installation (config.json, clé « dossier », ~ accepté : le même fichier
sert au PC et au Mac). S'il est dans un dépôt git, tout est commité, et poussé si le dépôt suit
une branche distante : une autre machine peut reprendre. « git »: false n'y touche jamais ;
« git »: true refuse d'écrire tant que le dossier n'est pas dans un dépôt (vault pas encore cloné).
Un dossier relatif est toujours refusé : il finirait dans le projet en cours.

    python passation.py write --dir <projet>   # sections sur stdin -> écrit (commit, push)
    python passation.py show  --dir <projet>   # affiche la passation en attente
    python passation.py done  --dir <projet>   # l'archive dans l'historique (à la reprise)

Le projet est la racine git de --dir (ou du dossier courant), sinon ce dossier lui-même.
"""
import datetime
import functools
import glob
import json
import os
import re
import subprocess
import sys
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
NOWIN = 0x08000000 if sys.platform == 'win32' else 0  # pas de console qui clignote sous Windows


def load_config():
    try:
        with open(os.path.join(HERE, 'config.json'), encoding='utf-8') as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


CONFIG = load_config()
DOSSIER = os.path.normpath(os.path.expanduser(
    os.environ.get('CONTEXT_PASSATION_DOSSIER') or CONFIG.get('dossier')
    or os.path.join('~', '.claude', 'passations')))


def run(args, timeout=20):
    try:
        return subprocess.run(args, capture_output=True, text=True, encoding='utf-8',
                              errors='replace', timeout=timeout, creationflags=NOWIN)
    except (OSError, subprocess.TimeoutExpired) as e:
        return subprocess.CompletedProcess(args, 1, '', str(e))


def posix(p):
    return p.replace('\\', '/')


# ── Projet ──────────────────────────────────────────────────────────────────
def project_root(d):
    r = run(['git', '-C', d, 'rev-parse', '--show-toplevel'], timeout=5)
    return os.path.normpath(r.stdout.strip()) if r.returncode == 0 and r.stdout.strip() else os.path.normpath(d)


def slug(name):
    s = unicodedata.normalize('NFKD', name).encode('ascii', 'ignore').decode().lower()
    return re.sub(r'[^a-z0-9._-]+', '-', s).strip('-') or 'projet'


def project(d):
    root = project_root(d)
    return slug(os.path.basename(root)), root


# ── Dossier des passations et git ───────────────────────────────────────────
@functools.lru_cache(maxsize=None)
def repo():
    """(racine du dépôt git qui contient DOSSIER, suit une branche distante) ou (None, False).

    Garde-fou : un dossier relatif (config d'une autre machine, « C:/… » lu sur un Mac) est refusé,
    sinon la passation partirait dans le projet en cours et son dépôt git. Avec « git »: true, un
    dossier hors de tout dépôt l'est aussi : le vault n'est pas encore cloné, ne pas le créer à sa place.
    """
    if not os.path.isabs(DOSSIER):
        raise RuntimeError(f'dossier des passations relatif ({posix(DOSSIER)}) : '
                           'mets un chemin absolu, ou ~/..., dans config.json')
    if CONFIG.get('git') is False:
        return None, False
    p = DOSSIER
    while not os.path.isdir(p) and os.path.dirname(p) != p:  # le dossier n'existe pas encore : on regarde son parent
        p = os.path.dirname(p)
    r = run(['git', '-C', p, 'rev-parse', '--show-toplevel'], timeout=5)
    if r.returncode != 0 or not r.stdout.strip():
        if CONFIG.get('git') is True:
            raise RuntimeError(f"{posix(DOSSIER)} n'est dans aucun dépôt git : clone le vault d'abord "
                               '(config.json exige git)')
        return None, False
    top = os.path.normpath(r.stdout.strip())
    upstream = run(['git', '-C', top, 'rev-parse', '--abbrev-ref', '@{u}'], timeout=5).returncode == 0
    return top, upstream


def git(*args, timeout=20):
    return run(['git', '-C', repo()[0], *args], timeout=timeout)


def error(r, default):
    lines = [l.strip() for l in (r.stderr or r.stdout or '').splitlines() if l.strip()]
    return lines[0] if lines else default


def name(projet, stamp='20*'):
    # "-20*" : le projet « app » ne ramasse pas les passations de « app-web »
    return f'{projet}-{stamp}.md'


def files(projet):
    return sorted(glob.glob(os.path.join(DOSSIER, name(projet))))


def history(projet):
    return os.path.join(DOSSIER, 'historique', f'{projet}.md')


def archive(path, projet, statut):
    """Déplace une passation en tête de l'historique du projet (titres décalés d'un niveau)."""
    with open(path, encoding='utf-8') as fh:
        lines = fh.read().strip().splitlines()
    entry = [('#' + l + (f' · {statut}' if i == 0 else '')) if l.startswith('#') else l
             for i, l in enumerate(lines)]
    hist = history(projet)
    head = f'# Historique des passations — {projet}\n\n'
    old = ''
    if os.path.exists(hist):
        with open(hist, encoding='utf-8') as fh:
            old = fh.read()
        old = old[len(head):] if old.startswith(head) else old
    os.makedirs(os.path.dirname(hist), exist_ok=True)
    with open(hist, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write(head + '\n'.join(entry) + '\n\n' + old.lstrip('\n'))
    os.remove(path)


def latest(projet):
    f = files(projet)
    return f[-1] if f else None


def display(path):
    top = repo()[0]
    return posix(os.path.relpath(path, top) if top else path)


def commande(cmd, cwd):
    """Commande passation.py exacte pour cette machine : le python qui lance les hooks, le chemin du skill."""
    return f'"{posix(sys.executable)}" "{posix(os.path.join(HERE, "passation.py"))}" {cmd} --dir "{posix(cwd)}"'


def pull(timeout=15):
    """Récupère les passations écrites ailleurs. Renvoie '' ou l'erreur."""
    top, upstream = repo()
    if not (top and upstream):
        return ''
    r = git('pull', '--rebase', '--autostash', '-q', timeout=timeout)
    return '' if r.returncode == 0 else error(r, 'pull impossible')


def commit_push(projet, message):
    """Commit des ajouts/suppressions de passations du projet, puis push. Renvoie '' ou l'erreur."""
    top, upstream = repo()
    if not top:
        return ''
    spec = [posix(os.path.relpath(p, top)) for p in (os.path.join(DOSSIER, name(projet)), history(projet))]
    for s in spec:  # un par un : un chemin absent ferait échouer tout le add
        git('add', '-A', '--', s)
    if not git('status', '--porcelain', '--', *spec).stdout.strip():
        return ''
    c = git('commit', '-q', '-m', message)
    if c.returncode != 0:
        return error(c, 'commit impossible')
    if not upstream:
        return ''
    p = git('push', '-q')
    if p.returncode != 0:
        pull()
        p = git('push', '-q')
    return '' if p.returncode == 0 else error(p, 'push refusé')


def write(projet, root, body):
    now = datetime.datetime.now()
    stamp = now.strftime('%Y-%m-%d-%H%M')
    err_pull = pull()
    for f in files(projet):
        archive(f, projet, f"remplacée sans reprise le {now.strftime('%Y-%m-%d %H:%M')}")
    os.makedirs(DOSSIER, exist_ok=True)
    path = os.path.join(DOSSIER, name(projet, stamp))
    head = f"# Passation — {projet} — {now.strftime('%Y-%m-%d %H:%M')}\n\nDossier : {root}\n\n"
    with open(path, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write(head + body.strip() + '\n')
    err = commit_push(projet, f'Claude Code : passation {projet} {stamp}')
    if not err and err_pull:
        err = 'pull impossible avant écriture : ' + err_pull
    return display(path), err


def done(projet):
    pull()
    fs = files(projet)
    for f in fs:
        archive(f, projet, f"reprise le {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    return len(fs), commit_push(projet, f'Claude Code : reprise {projet}') if fs else ''


# ── État, marqueurs et transcript, partagés par les hooks ───────────────────
STATE_DIR = os.path.join(os.path.expanduser('~'), '.claude', 'context-passation', 'sessions')
SLEEP_DIR = os.path.join(os.path.expanduser('~'), '.claude', 'context-passation', 'endormies')


def sleep_marker(projet):
    return os.path.join(SLEEP_DIR, f'{projet}.json')


def tail_lines(path, size):
    """Lignes de la fin du transcript, de la plus récente à la plus ancienne."""
    with open(path, 'rb') as fh:
        fh.seek(0, 2)
        end = fh.tell()
        fh.seek(max(0, end - size))
        lines = fh.read().split(b'\n')
    return reversed(lines[1:] if end > size else lines)  # la première ligne est coupée


def entry(line):
    """Entrée JSON de la session principale (None pour un sous-agent ou une ligne illisible)."""
    try:
        e = json.loads(line)
    except ValueError:
        return None
    return e if isinstance(e, dict) and not e.get('isSidechain') else None


def state_path(sid):
    return os.path.join(STATE_DIR, re.sub(r'[^A-Za-z0-9_-]', '', sid or 'inconnue') + '.json')


def load_state(sid):
    try:
        with open(state_path(sid), encoding='utf-8') as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def save_state(sid, st):
    os.makedirs(STATE_DIR, exist_ok=True)
    with open(state_path(sid), 'w', encoding='utf-8') as fh:
        json.dump(st, fh)


def hook_input():
    try:
        return json.loads(sys.stdin.buffer.read().decode('utf-8', errors='replace') or '{}')
    except ValueError:
        return {}


def hook_output(event, context, message=None):
    out = {'hookSpecificOutput': {'hookEventName': event, 'additionalContext': context}}
    if message:
        out['systemMessage'] = message
    sys.stdout.write(json.dumps(out, ensure_ascii=True))


def main():
    for s in (sys.stdout, sys.stderr):
        s.reconfigure(encoding='utf-8')
    args = sys.argv[1:]
    d = os.getcwd()
    if '--dir' in args:
        i = args.index('--dir')
        d = args[i + 1]
        del args[i:i + 2]
    cmd = args[0] if args else ''
    projet, root = project(d)
    if cmd in ('write', 'show', 'done'):
        try:
            repo()  # garde-fou (dossier relatif ou hors git) : un message net plutôt qu'une trace
        except RuntimeError as e:
            sys.exit(f'context-passation : {e}')
    if cmd == 'write':
        body = sys.stdin.buffer.read().decode('utf-8', errors='replace')
        if not body.strip():
            sys.exit('Contenu vide : passe les sections sur stdin (heredoc).')
        path, err = write(projet, root, body)
        print(path)
        if err:
            print(f'Pas poussée sur git : {err}')
    elif cmd == 'show':
        pull()
        f = latest(projet)
        if f:
            print(f'[{display(f)}]')
            print(open(f, encoding='utf-8').read())
        else:
            print(f'Aucune passation pour {projet}.')
    elif cmd == 'done':
        n, err = done(projet)
        print(f'{n} passation(s) archivée(s) dans {display(history(projet))}.' + (f' Pas poussé sur git : {err}' if err else ''))
    else:
        sys.exit(__doc__)


if __name__ == '__main__':
    main()
