"""Hook SessionStart (startup|clear|compact) : injecte la passation du projet.

startup / clear : la passation en attente, dans la nouvelle session. Si la session précédente a
été bloquée comme endormie (marqueur écrit par context_watch.py), écrit d'abord une fiche
automatique tirée de son transcript, sans appeler de modèle.
compact : la fiche écrite pendant cette session, juste avant la compaction automatique.
Note aussi le modèle et le début de la session, pour context_watch.py et la reprise après compaction.
"""
import glob
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import passation as P  # noqa: E402

EDITS = ('Edit', 'MultiEdit', 'Write', 'NotebookEdit')


def prune(folder, days):
    limit = time.time() - days * 86400
    for f in glob.glob(os.path.join(folder, '*.json')):
        try:
            if os.path.getmtime(f) < limit:
                os.remove(f)
        except OSError:
            pass


def user_text(e):
    """Texte d'un vrai message de l'utilisateur (vide pour un résultat d'outil, un rappel, une commande)."""
    if e.get('type') != 'user' or e.get('isMeta') or e.get('isCompactSummary'):
        return ''
    c = (e.get('message') or {}).get('content')
    if isinstance(c, list):
        if any(isinstance(b, dict) and b.get('type') == 'tool_result' for b in c):
            return ''
        c = ' '.join(b.get('text', '') for b in c if isinstance(b, dict) and b.get('type') == 'text')
    c = (c or '').strip()
    return '' if c.startswith('<') else c


def short(text, n):
    text = ' '.join(text.split())
    return text if len(text) <= n else text[:n - 1] + '…'


def auto_fiche(marker):
    """Corps d'une fiche tirée de la fin du transcript : derniers messages, dernière réponse, fichiers modifiés."""
    path = marker.get('transcript_path') or ''
    if not os.path.isfile(path):
        return ''
    prompts, answer, edited = [], '', []
    for line in P.tail_lines(path, 8 << 20):
        e = P.entry(line)
        if not e:
            continue
        t = user_text(e)
        if t and len(prompts) < 3:
            prompts.append(short(t, 300))
        if e.get('type') == 'assistant':
            for b in reversed((e.get('message') or {}).get('content') or []):
                if not isinstance(b, dict):
                    continue
                if b.get('type') == 'text' and b.get('text', '').strip() and not answer:
                    answer = b['text'].strip()
                if b.get('type') == 'tool_use' and b.get('name') in EDITS:
                    inp = b.get('input') or {}
                    fp = inp.get('file_path') or inp.get('notebook_path')
                    if fp and fp not in edited and len(edited) < 5:
                        edited.append(fp)
        if len(prompts) == 3 and answer and len(edited) == 5:
            break
    lines = ["Fiche automatique, écrite sans modèle depuis le transcript (session endormie).", '',
             "## Ce qui était en cours", "- Derniers messages de l'utilisateur :"]
    lines += [f'  - « {p} »' for p in reversed(prompts)] or ['  - (aucun)']
    if answer:
        lines.append("- Dernière réponse de l'assistant :")
        lines += ['  > ' + l for l in short(answer, 1200).splitlines() or ['']]
    lines += ['', '## Prochaine étape', f"- {short(marker.get('prompt') or 'reprendre là où on en était', 600)}",
              '', '## Fichiers à relire']
    lines += [f'- {P.posix(f)}' for f in edited] or ['- (aucun fichier modifié repéré)']
    return '\n'.join(lines)


def write_sleep_fiche(projet, root):
    marker = P.sleep_marker(projet)
    if not os.path.exists(marker):
        return
    try:
        with open(marker, encoding='utf-8') as fh:
            m = json.load(fh)
    except (OSError, ValueError):
        m = None
    fresh = time.time() - os.path.getmtime(marker) < 7 * 86400
    os.remove(marker)
    body = auto_fiche(m) if m and fresh else ''
    if body:
        P.write(projet, root, body)


def main():
    data = P.hook_input()
    sid, source = data.get('session_id', ''), data.get('source', '')
    st = P.load_state(sid)
    if data.get('model') or 'debut' not in st:
        st['model'] = data.get('model') or st.get('model', '')
        st.setdefault('debut', time.time())
        P.save_state(sid, st)
    prune(P.STATE_DIR, 14)
    prune(P.SLEEP_DIR, 7)

    # claude -p / SDK : pas de passation injectée dans les sessions automatisées
    if os.environ.get('CLAUDE_CODE_ENTRYPOINT', '').startswith('sdk') and not os.environ.get('CONTEXT_PASSATION_FORCE'):
        return
    if source not in ('startup', 'clear', 'compact'):
        return
    cwd = data.get('cwd') or os.getcwd()
    projet, root = P.project(cwd)
    if source != 'compact':
        write_sleep_fiche(projet, root)
        P.pull(timeout=8)  # la passation a pu être écrite sur une autre machine
    f = P.latest(projet)
    if not f or (source == 'compact' and os.path.getmtime(f) < st['debut']):
        return  # après une compaction, seule une fiche écrite pendant cette session compte
    nom = P.display(f)
    contenu = open(f, encoding='utf-8').read()
    done = P.commande('done', cwd)
    relire = ("Avant d'attaquer la « Prochaine étape », ne relis que les « Fichiers à relire » de la fiche : "
              "ne réexplore pas tout le projet.")

    if source == 'compact':
        consigne = (
            "La conversation vient d'être compactée. Tu as écrit la fiche de passation "
            "ci-dessous juste avant (skill context-passation) : elle complète le résumé. Ta prochaine "
            f"commande l'archive dans l'historique du projet : {done} ; puis continue exactement là où tu "
            "en étais, sans rien redemander à l'utilisateur. Ne relis que les « Fichiers à relire » dont "
            "tu as besoin : ne réexplore pas tout le projet.")
    elif source == 'clear':
        consigne = (
            "L'utilisateur vient d'envoyer /new après une passation (skill context-passation). "
            "À son prochain message, même un simple « go » : ta toute première commande archive la "
            f"passation dans l'historique du projet (son contenu est ci-dessous) : {done} ; "
            f"puis reprends exactement à la « Prochaine étape », sans rien lui redemander. {relire}")
    else:
        consigne = (
            f"Une passation non reprise existe pour ce projet ({nom}). "
            "S'il te demande de reprendre, reprends directement à la « Prochaine étape ». "
            "Sinon, au début de ta première réponse, propose-lui en une ligne de reprendre ; "
            "s'il veut faire autre chose, fais ce qu'il demande. "
            f"Dès qu'il a choisi, archive la passation dans l'historique du projet : {done}. {relire}")
    P.hook_output('SessionStart', f'[context-passation] {consigne}\n\n--- {nom} ---\n{contenu}',
                  f'context-passation : passation {nom} ' + ('rechargée après la compaction' if source == 'compact' else 'chargée'))


if __name__ == '__main__':
    try:
        main()
    except Exception as e:  # un hook ne doit jamais bloquer le démarrage
        sys.stderr.write(f'context-passation (SessionStart) : {e}\n')
