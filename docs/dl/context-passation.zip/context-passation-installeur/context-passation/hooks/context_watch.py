"""Hooks UserPromptSubmit et PostToolUse : mesurent le contexte réel et demandent la fiche de passation.

À chaque message de l'utilisateur et après chaque outil (une longue tâche autonome peut
saturer le contexte sans message intermédiaire). Tokens = usage du dernier message de
l'assistant dans le transcript (entrée + cache). Prévient au seuil (300k tokens par défaut,
80 % de la fenêtre de compaction au plus), puis tous les 100k. Les outils des sous-agents sont ignorés.

Trois cas, selon la compaction automatique (autoCompactWindow, réglé par l'installeur) :
- elle part moins de 100k tokens après le seuil : Claude écrit la fiche et continue ; la
  compaction suit et session_start.py réinjecte la fiche ;
- elle est plus loin (pas d'autoCompactWindow, ou session lancée avant le réglage) : pareil,
  sans s'arrêter ; la fiche est redemandée tous les 100k jusqu'à la compaction ;
- elle est coupée : Claude écrit la fiche et demande /new, rien d'autre ne videra le contexte.
Après une compaction, le palier repart de zéro : la fiche sera redemandée au prochain seuil.

Session endormie (cache expiré sur une grosse session) : par défaut rien ne bloque, le message
part et la conversation est relue en entier, pour qu'une session autonome ne s'arrête jamais.
Garde facultative (UserPromptSubmit), coupée par défaut : avec garde_tokens, le message est
bloqué avant d'être envoyé ; le renvoyer le laisse passer, /new repart d'une fiche tirée du
transcript (écrite par session_start.py).

Réglages (variable d'environnement, sinon clé de config.json) :
CONTEXT_PASSATION_SEUIL_TOKENS / seuil_tokens (300000), CONTEXT_PASSATION_GARDE_TOKENS /
garde_tokens (0 = garde coupée ; 150000 pour bloquer une session endormie de cette taille),
CONTEXT_PASSATION_WINDOW (fenêtre forcée, en tokens).
"""
import datetime
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import passation as P  # noqa: E402

SETTINGS = os.path.join(os.path.expanduser('~'), '.claude', 'settings.json')
PAS = 100_000
MARGE = 13_000     # Claude Code compacte à « fenêtre − 13k »
PROCHE = 100_000   # au-delà, la compaction est loin du seuil : la fiche sera redemandée avant qu'elle parte
DEPASSE = 20_000   # mesuré au-delà du point de compaction : elle n'est pas active dans cette session


def reglage(env, cle, defaut):
    v = os.environ.get(env)
    if v is None:
        v = P.CONFIG.get(cle, defaut)
    try:
        return int(v)
    except (TypeError, ValueError):
        return defaut


SEUIL_TOKENS = reglage('CONTEXT_PASSATION_SEUIL_TOKENS', 'seuil_tokens', 300_000)
GARDE_TOKENS = reglage('CONTEXT_PASSATION_GARDE_TOKENS', 'garde_tokens', 0)


def read_settings():
    try:
        with open(SETTINGS, encoding='utf-8') as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def scan(path):
    """(tokens et horodatage du dernier appel au modèle, uuid de la dernière compaction).

    Juste après une compaction, avant tout nouvel appel au modèle, les tokens sont ceux qu'elle a laissés.
    """
    tokens, ts, compact, boundary_seen = None, '', '', False
    for size in (4 << 20, 32 << 20):  # la compaction n'est cherchée que dans les 4 derniers Mo
        for line in P.tail_lines(path, size):
            if not boundary_seen and size == 4 << 20 and b'"compact_boundary"' in line:
                e = P.entry(line)
                if e and e.get('subtype') == 'compact_boundary':
                    boundary_seen, compact = True, e.get('uuid', '')
                    if tokens is None:  # les appels plus anciens mesurent le contexte d'avant la compaction
                        tokens, ts = (e.get('compactMetadata') or {}).get('postTokens') or 0, e.get('timestamp', '')
            elif tokens is None and b'"usage"' in line:
                e = P.entry(line)
                m = e.get('message') if e and e.get('type') == 'assistant' else None
                if isinstance(m, dict) and m.get('model') != '<synthetic>':
                    u = m.get('usage') or {}
                    t = sum(u.get(k) or 0 for k in ('input_tokens', 'cache_creation_input_tokens', 'cache_read_input_tokens'))
                    tokens, ts = (t, e.get('timestamp', '')) if t else (None, '')
            if tokens is not None and boundary_seen:
                break
        if tokens is not None or os.path.getsize(path) <= size:
            break
    return tokens, ts, compact


def window(model, tokens, settings):
    if os.environ.get('CONTEXT_PASSATION_WINDOW'):
        return int(os.environ['CONTEXT_PASSATION_WINDOW'])
    model = model or settings.get('model', '')
    w = 1_000_000 if '[1m]' in model.lower() or tokens > 200_000 else 200_000
    # Claude Code compacte avant la fenêtre si on la réduit (réglage ou variable d'environnement)
    for cap in (os.environ.get('CLAUDE_CODE_AUTO_COMPACT_WINDOW'), settings.get('autoCompactWindow')):
        try:
            w = min(w, int(cap)) if cap else w
        except ValueError:
            pass
    return w


def oui(v):
    return str(v or '').strip().lower() not in ('', '0', 'false', 'no')


def compaction_active(settings):
    """False si la compaction automatique est coupée (variable d'environnement ou /config)."""
    if oui(os.environ.get('DISABLE_AUTO_COMPACT')) or oui(os.environ.get('DISABLE_COMPACT')):
        return False
    if settings.get('autoCompactEnabled') is False:
        return False
    try:
        with open(os.path.join(os.path.expanduser('~'), '.claude.json'), encoding='utf-8') as fh:
            return json.load(fh).get('autoCompactEnabled') is not False
    except (OSError, ValueError):
        return True


def cache_ttl(settings):
    v = os.environ.get('CLAUDE_CODE_PROMPT_CACHE_TTL') or settings.get('promptCacheTtl') or '1h'
    return 300 if str(v).strip().lower() == '5m' else 3600


def asleep_for(ts):
    """Secondes écoulées depuis l'horodatage ISO du transcript (0 si illisible)."""
    try:
        t = datetime.datetime.fromisoformat(ts.replace('Z', '+00:00'))
    except (AttributeError, ValueError):
        return 0
    return (datetime.datetime.now(datetime.timezone.utc) - t).total_seconds()


def duration(s):
    h, m = int(s // 3600), int(s % 3600 // 60)
    return f'{h // 24} jours' if h >= 48 else f'{h} h {m:02d}'


QUAND = {
    'UserPromptSubmit': (
        "Si la demande de l'utilisateur ci-dessus se règle en une réponse courte, traite-la d'abord ; "
        "sinon, écris la fiche tout de suite, avec sa demande comme « Prochaine étape »."),
    'PostToolUse': (
        "Termine l'action en cours sans la couper, puis écris la fiche avant de continuer : "
        "la « Prochaine étape » est la suite de ton travail."),
}


def aide(data):
    """La commande write exacte de cette machine : le skill n'a pas à deviner l'interpréteur ni le chemin."""
    return (" Commande sur cette machine : " + P.commande('write', data.get('cwd') or os.getcwd())
            + " (les sections en heredoc sur stdin, voir le skill).")


def consigne(event, compaction, active):
    """Ce que Claude fait au seuil. compaction : tokens où elle partira si elle est proche, sinon None ;
    active : False si la compaction automatique est coupée (seul cas où Claude s'arrête pour demander /new)."""
    if compaction:
        quoi = ("Déclenche le skill context-passation : écris la fiche de passation, puis continue sans "
                f"demander /new. La compaction automatique suivra vers {compaction // 1000}k tokens et la "
                "fiche sera réinjectée juste après.")
    elif active:
        quoi = ("Déclenche le skill context-passation : écris la fiche de passation, puis continue sans "
                "demander /new. Dans cette session la compaction automatique viendra plus tard : la fiche "
                "sera redemandée tous les 100k tokens et réinjectée juste après la compaction.")
    else:
        quoi = ("Déclenche le skill context-passation maintenant : écris la fiche de passation, puis demande /new "
                "(la compaction automatique est coupée, rien d'autre ne videra le contexte).")
    return f'{quoi} {QUAND[event]}'


def sleep_guard(data, st, sid, tokens, ts, settings):
    """True si le message a été bloqué (session endormie sur un gros contexte)."""
    if (GARDE_TOKENS <= 0 or tokens < GARDE_TOKENS or not ts
            or os.environ.get('CLAUDE_CODE_ENTRYPOINT', '').startswith('sdk')):
        return False
    gap = asleep_for(ts)
    if gap <= cache_ttl(settings):
        return False
    projet, _ = P.project(data.get('cwd') or os.getcwd())
    marker = P.sleep_marker(projet)
    if st.get('idle_ok') == ts:  # déjà prévenu pour ce réveil : il a renvoyé son message, on laisse passer
        if os.path.exists(marker):
            os.remove(marker)
        return False
    st['idle_ok'] = ts
    P.save_state(sid, st)
    os.makedirs(P.SLEEP_DIR, exist_ok=True)
    with open(marker, 'w', encoding='utf-8') as fh:
        json.dump({'transcript_path': data.get('transcript_path'), 'cwd': data.get('cwd') or os.getcwd(),
                   'prompt': data.get('prompt', ''), 'tokens': tokens}, fh, ensure_ascii=False)
    reason = (f"Session endormie depuis {duration(gap)} : le cache a expiré, ce message ferait réécrire "
              f"{tokens // 1000}k tokens, le coût d'une vingtaine de messages normaux. "
              "Pour repartir léger : /new puis go, je reprends avec une fiche tirée du transcript et ton "
              "message comme prochaine étape. Pour continuer ici quand même : renvoie ton message (flèche haut).")
    sys.stdout.write(json.dumps({'decision': 'block', 'reason': reason}, ensure_ascii=True))
    return True


def main():
    data = P.hook_input()
    event = data.get('hook_event_name') or 'UserPromptSubmit'
    sid, path = data.get('session_id', ''), data.get('transcript_path', '')
    if event not in QUAND or data.get('agent_id') or not path or not os.path.isfile(path):
        return
    tokens, ts, compact = scan(path)
    st = P.load_state(sid)
    settings = read_settings()
    changed = False
    if 'debut' not in st:  # session commencée avant l'installation : une fiche plus ancienne ne sera pas réinjectée
        st['debut'], changed = time.time(), True

    if event == 'UserPromptSubmit' and tokens and sleep_guard(data, st, sid, tokens, ts, settings):
        return

    if compact and compact != st.get('compact_seen'):  # après une compaction, le palier repart de zéro
        st['compact_seen'], st['palier'], changed = compact, 0, True

    if tokens:
        w = window(st.get('model', ''), tokens, settings)
        seuil = min(SEUIL_TOKENS, int(w * 0.8))
        if tokens < seuil // 2 and st.get('palier'):  # compaction pas repérée, ou retour en arrière
            st['palier'], changed = 0, True
        palier = seuil + (tokens - seuil) // PAS * PAS if tokens >= seuil else 0
        if palier > st.get('palier', 0):
            st['palier'] = palier
            P.save_state(sid, st)
            compaction = w - MARGE
            active = compaction_active(settings)
            proche = (active and compaction - seuil <= PROCHE
                      and tokens < compaction + DEPASSE)  # au-delà : session lancée avant le réglage
            P.hook_output(event, f"[context-passation] Contexte à {tokens // 1000}k tokens (seuil {seuil // 1000}k). "
                                 + consigne(event, compaction if proche else None, active) + aide(data),
                          f'context-passation : contexte à {tokens // 1000}k tokens, fiche de passation demandée')
            return
    if changed:
        P.save_state(sid, st)


if __name__ == '__main__':
    try:
        main()
    except Exception as e:  # un hook ne doit jamais bloquer un message
        sys.stderr.write(f'context-passation (context_watch) : {e}\n')
