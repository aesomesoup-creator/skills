# context-passation

Un skill Claude Code pour les longues sessions. Quand une conversation devient trop longue, Claude
perd le fil, chaque message coûte plus cher (tout le contexte est relu), puis Claude Code la
compacte et des détails se perdent. Ce skill mesure le contexte réellement utilisé. Juste avant la
compaction automatique, Claude écrit une courte fiche de passation : ce qui est en cours, les
décisions prises, ce qu'il ne faut pas oublier, la prochaine étape et les fichiers à relire. La
compaction passe, la fiche est réinjectée, et Claude reprend là où il en était, sans s'arrêter et
sans rien te demander. Une session autonome peut ainsi tourner des heures.

## Installer

Il te faut Claude Code et Python 3.8 ou plus. Git est facultatif. Sous Windows, Git for Windows
est recommandé : Claude Code s'en sert pour son outil Bash.

```
python install.py        # Windows
python3 install.py       # macOS / Linux
```

L'installeur demande où ranger les passations. Par défaut, c'est `~/.claude/passations`. Un
dossier de ton vault Obsidian est idéal : tu y relis les fiches. Si ce dossier est dans un dépôt
git, chaque passation y est commitée et poussée, et tu peux la reprendre sur une autre machine.
Les hooks s'activent dans les nouvelles sessions Claude Code.

L'installeur règle aussi la compaction automatique de Claude Code à 300k tokens
(`autoCompactWindow` dans `~/.claude/settings.json`), sauf si tu as déjà choisi une valeur. Sans ce
réglage, un modèle à 1M de contexte ne compacte que vers 987k : le skill fonctionne quand même, mais
chaque message relit un contexte bien plus gros.

Options :
- `--dossier <chemin>` choisit le dossier sans poser la question ;
- `--sans-git` n'utilise jamais git ;
- `--desinstaller` retire le skill, les hooks et le réglage `autoCompactWindow` s'il vient de
  l'installeur, mais laisse les passations en place.

Pour mettre à jour, relance simplement l'installation : elle garde le dossier choisi.

## Comment ça marche

- **Mesure** : à chaque message et après chaque outil (hooks `UserPromptSubmit` et
  `PostToolUse`, environ 0,1 s), le nombre réel de tokens est lu dans le transcript de la
  session. Claude est prévenu à 80 % de la fenêtre de compaction (240k avec le réglage de
  l'installeur), puis tous les 100k. Après une compaction, le compteur repart de zéro.
  Pendant une longue tâche autonome, il termine l'action en cours avant d'écrire la passation.
- **Passation** : Claude écrit `<dossier>/<projet>-AAAA-MM-JJ-HHMM.md`, puis continue son
  travail. Il y a une seule fiche en attente par projet.
- **Reprise après la compaction** : un hook `SessionStart` réinjecte la fiche écrite pendant la
  session, à côté du résumé de la compaction. Claude l'archive et continue, en ne relisant que
  les fichiers indiqués.
- **Il ne s'arrête jamais de lui-même**, sauf dans un cas : si tu as coupé la compaction
  automatique, rien d'autre ne videra le contexte, et Claude te demande `/new` après la fiche.
- **`/new` à la main** : tu peux toujours repartir d'un contexte vide. Dis « reset » ou
  « nouvelle session », Claude écrit la fiche, tu tapes `/new` puis « go », et la nouvelle
  session reprend à la « Prochaine étape ». Si tu ouvres une nouvelle fenêtre à la place, Claude
  te propose de reprendre la fiche en attente.
- **Session endormie** : le cache de Claude expire après une heure. Revenir sur une grosse
  session après ce délai fait relire tout le contexte, au prix d'une vingtaine de messages
  normaux pour ce message-là. Par défaut rien ne bloque : le message part et la session continue.
  Une garde facultative (`garde_tokens`, voir les réglages) bloque ce message à la place : tu le
  renvoies pour continuer quand même, ou tu tapes `/new` puis « go », et une fiche automatique
  est tirée du transcript, sans appeler le modèle, avec ton message comme prochaine étape.
- **Historique** : une fiche reprise, ou remplacée par une nouvelle, passe en tête de
  `<dossier>/historique/<projet>.md`. Ce fichier forme le journal des sessions du projet.

L'installeur ajoute ses hooks et `autoCompactWindow` à `~/.claude/settings.json`, sans toucher au reste. Il en fait
d'abord une sauvegarde dans `settings.json.bak-context-passation`.

## Réglages (variables d'environnement)

| Variable | Défaut | Effet |
|---|---|---|
| `CONTEXT_PASSATION_SEUIL_TOKENS` | `300000` | seuil de la passation (rappel tous les 100k) ; plafonné à 80 % de la fenêtre de compaction |
| `CONTEXT_PASSATION_GARDE_TOKENS` | `0` | garde « session endormie », coupée par défaut ; `150000` bloque le réveil d'une session de cette taille |
| `CONTEXT_PASSATION_WINDOW` | auto | force la taille du contexte en tokens (auto : 1M pour les modèles `[1m]`, 200k sinon, plafonné par `autoCompactWindow`) |

Les deux premiers réglages peuvent aussi être écrits dans `~/.claude/skills/context-passation/config.json`
(`seuil_tokens`, `garde_tokens`).
